package com.canvaplayer.app.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object FileUtils {

    /** Reads the display name of a content:// Uri picked via the system file picker. */
    fun queryDisplayName(context: Context, uri: Uri): String? {
        var name: String? = null
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && it.moveToFirst()) {
                name = it.getString(nameIndex)
            }
        }
        return name
    }

    fun extensionOf(fileName: String): String =
        fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)

    fun nameWithoutExtension(fileName: String): String =
        fileName.substringBeforeLast('.', fileName)

    /** Generates a private, collision-free folder name for a newly imported project. */
    fun newProjectFolderName(): String = "canvas_${UUID.randomUUID().toString().take(12)}"

    /** Recursively computes the total size in bytes of a directory (or a single file). */
    fun sizeOf(file: File): Long {
        if (!file.exists()) return 0L
        if (file.isFile) return file.length()
        var total = 0L
        file.listFiles()?.forEach { total += sizeOf(it) }
        return total
    }

    fun humanReadableSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB")
        var value = bytes / 1024.0
        var unitIndex = 0
        while (value >= 1024 && unitIndex < units.size - 1) {
            value /= 1024.0
            unitIndex++
        }
        return String.format(Locale.getDefault(), "%.1f %s", value, units[unitIndex])
    }

    fun formatDate(timestampMillis: Long): String {
        if (timestampMillis <= 0L) return "-"
        val formatter = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.getDefault())
        return formatter.format(Date(timestampMillis))
    }

    /**
     * Recursively searches [root] for an entry HTML file, preferring `index.html`
     * or `index.htm` at the top level, then anywhere in the tree, then finally
     * falling back to any HTML file found. Returns the path relative to [root],
     * using forward slashes, or null if no HTML file exists anywhere inside.
     */
    fun findEntryHtml(root: File): String? {
        val topLevelIndex = listOf("index.html", "index.htm", "Index.html", "Index.htm")
            .map { File(root, it) }
            .firstOrNull { it.exists() && it.isFile }
        if (topLevelIndex != null) return topLevelIndex.name

        val allHtmlFiles = mutableListOf<File>()
        collectHtmlFiles(root, allHtmlFiles)
        if (allHtmlFiles.isEmpty()) return null

        val nestedIndex = allHtmlFiles.firstOrNull {
            it.name.equals("index.html", ignoreCase = true) || it.name.equals("index.htm", ignoreCase = true)
        }
        val chosen = nestedIndex ?: allHtmlFiles.minByOrNull { it.toRelativeString(root).count { c -> c == '/' } }
        return chosen?.toRelativeString(root)
    }

    private fun collectHtmlFiles(dir: File, out: MutableList<File>) {
        val children = dir.listFiles() ?: return
        for (child in children) {
            if (child.isDirectory) {
                collectHtmlFiles(child, out)
            } else if (child.extension.equals("html", ignoreCase = true) ||
                child.extension.equals("htm", ignoreCase = true)
            ) {
                out.add(child)
            }
        }
    }
}
