package com.canvaplayer.app.model

import org.json.JSONObject
import java.util.UUID

/**
 * Represents a single imported Canvas (an HTML file or an extracted ZIP project)
 * that lives inside Canva Player's private app storage.
 *
 * [folderName] is the directory under `filesDir/canvases/` that holds this
 * project's files. [entryRelativePath] is the path, relative to that folder,
 * of the HTML file that should be loaded first (usually "index.html").
 */
data class CanvasProject(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val folderName: String,
    val entryRelativePath: String,
    val dateAdded: Long = System.currentTimeMillis(),
    var lastOpened: Long = 0L,
    var favorite: Boolean = false,
    var internetEnabled: Boolean = false,
    var sizeBytes: Long = 0L,
    val sourceType: SourceType = SourceType.HTML
) {
    enum class SourceType { HTML, ZIP, BUILT_IN }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("folderName", folderName)
        put("entryRelativePath", entryRelativePath)
        put("dateAdded", dateAdded)
        put("lastOpened", lastOpened)
        put("favorite", favorite)
        put("internetEnabled", internetEnabled)
        put("sizeBytes", sizeBytes)
        put("sourceType", sourceType.name)
    }

    companion object {
        fun fromJson(json: JSONObject): CanvasProject = CanvasProject(
            id = json.getString("id"),
            name = json.getString("name"),
            folderName = json.getString("folderName"),
            entryRelativePath = json.getString("entryRelativePath"),
            dateAdded = json.optLong("dateAdded", System.currentTimeMillis()),
            lastOpened = json.optLong("lastOpened", 0L),
            favorite = json.optBoolean("favorite", false),
            internetEnabled = json.optBoolean("internetEnabled", false),
            sizeBytes = json.optLong("sizeBytes", 0L),
            sourceType = try {
                SourceType.valueOf(json.optString("sourceType", "HTML"))
            } catch (e: IllegalArgumentException) {
                SourceType.HTML
            }
        )
    }
}

enum class SortMode { NAME, DATE_ADDED, LAST_OPENED }

enum class LibraryFilter { ALL, FAVORITES, RECENT }
