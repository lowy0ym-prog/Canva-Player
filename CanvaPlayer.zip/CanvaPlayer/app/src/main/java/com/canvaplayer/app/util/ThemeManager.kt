package com.canvaplayer.app.util

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/**
 * Persists and applies the user's chosen app-wide appearance
 * (Light / Dark / Follow system). This only affects Canva Player's own UI —
 * it never touches or restyles the HTML/CSS of a Canvas project itself.
 */
object ThemeManager {

    const val MODE_LIGHT = 0
    const val MODE_DARK = 1
    const val MODE_SYSTEM = 2

    private const val PREFS_NAME = "canva_player_prefs"
    private const val KEY_THEME_MODE = "theme_mode"

    fun getSavedMode(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_THEME_MODE, MODE_SYSTEM)
    }

    fun applySavedMode(context: Context) {
        applyMode(getSavedMode(context))
    }

    fun setMode(context: Context, mode: Int) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_THEME_MODE, mode).apply()
        applyMode(mode)
    }

    private fun applyMode(mode: Int) {
        val nightMode = when (mode) {
            MODE_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            MODE_DARK -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }
}
