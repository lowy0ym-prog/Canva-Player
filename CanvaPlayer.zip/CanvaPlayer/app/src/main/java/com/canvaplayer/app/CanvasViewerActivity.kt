package com.canvaplayer.app

import android.annotation.SuppressLint
import android.util.Base64
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.databinding.ActivityCanvasViewerBinding
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.XlsxWriter
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Runs a single imported Canvas inside a locked-down WebView.
 *
 * This is NOT a browser: there is no address bar, no way to type a URL, and
 * top-level navigation to any page outside the Canvas's own project folder is
 * always blocked. The only network traffic ever allowed is sub-resource
 * traffic (fetch/XHR/images/fonts/etc.) initiated by the Canvas itself, and
 * only while the user has switched this project's Internet toggle ON.
 *
 * It also lets a Canvas's own "export/download" button actually save a real
 * file on the device: any CSV-style export a Canvas produces is
 * automatically converted into a genuine .xlsx workbook before the user
 * picks where to save it.
 */
class CanvasViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CANVAS_ID = "extra_canvas_id"
        private const val ASSET_DOMAIN = "appassets.androidplatform.net"
        private const val ASSET_PATH_PREFIX = "/canvas/"
        private const val MAX_HTTP_DOWNLOAD_BYTES = 50L * 1024 * 1024
        private const val MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }

    private lateinit var binding: ActivityCanvasViewerBinding
    private lateinit var repository: CanvasRepository
    private lateinit var project: CanvasProject
    private lateinit var assetLoader: WebViewAssetLoader
    private lateinit var startUrl: String

    // Holds the bytes waiting to be written once the user picks a save
    // location via the system "Save as" picker (Storage Access Framework).
    private var pendingExportBytes: ByteArray? = null
    private var pendingExportName: String? = null

    private val saveXlsxLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument(MIME_XLSX)
    ) { uri -> writePendingExport(uri) }

    private val saveGenericLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri -> writePendingExport(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCanvasViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = CanvasRepository.getInstance(this)
        val canvasId = intent.getStringExtra(EXTRA_CANVAS_ID)
        val loaded = canvasId?.let { repository.getById(it) }

        if (loaded == null) {
            Toast.makeText(this, R.string.error_title, Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        project = loaded

        val projectDir = repository.projectDir(project)
        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(ASSET_DOMAIN)
            .addPathHandler(ASSET_PATH_PREFIX, WebViewAssetLoader.InternalStoragePathHandler(this, projectDir))
            .build()
        startUrl = "https://$ASSET_DOMAIN$ASSET_PATH_PREFIX${project.entryRelativePath}"

        binding.txtCanvasName.text = project.name
        setupWebView()
        setupTopBar()
        setupBackHandling()

        loadCanvas()
    }

    // ---------------------------------------------------------------------
    // WebView setup
    // ---------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        // Belt-and-suspenders against any "open a new browser-like window"
        // escape hatch: a Canvas cannot pop a second window via
        // window.open()/target="_blank" — there is nowhere for it to go.
        // (These already default to false/false on Android, but we set them
        // explicitly so this guarantee never depends on a platform default.)
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)

        // Narrow, single-purpose JS bridge: it can only hand a file's bytes
        // back to Android to be saved. It exposes nothing else — no reads,
        // no device APIs, no arbitrary code execution surface.
        webView.addJavascriptInterface(ExportBridge(), "AndroidExport")

        // Many "Export" buttons create a blob: URL, click a hidden download
        // link, then immediately call URL.revokeObjectURL(). That revoke can
        // race ahead of the async fetch we do below to pull the file's bytes
        // back out of the page, silently breaking the export. Delaying the
        // actual revoke by a few seconds (the page still thinks it happened
        // immediately) closes that race without changing anything the page
        // can observe.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                webView,
                """
                (function() {
                  if (window.__cpBlobPatched) return;
                  window.__cpBlobPatched = true;
                  var origRevoke = URL.revokeObjectURL.bind(URL);
                  URL.revokeObjectURL = function(url) {
                    setTimeout(function() { origRevoke(url); }, 5000);
                  };
                })();
                """.trimIndent(),
                setOf("https://$ASSET_DOMAIN/*")
            )
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // Never create a second window/tab for any reason — a Canvas has
            // exactly one page, always. This is the same guarantee as above,
            // enforced again at the point where a new-window request would
            // actually be granted.
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }

        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            handleDownload(url, contentDisposition, mimeType)
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url ?: return super.shouldInterceptRequest(view, request)

                // Local project files always work, online or offline.
                if (url.host == ASSET_DOMAIN) {
                    return assetLoader.shouldInterceptRequest(url)
                }

                val scheme = url.scheme?.lowercase()
                if ((scheme == "http" || scheme == "https") && !project.internetEnabled) {
                    // Internet toggle is OFF: block the network sub-resource,
                    // but let the rest of the (local) Canvas keep working.
                    return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                }

                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                // Any top-level (main-frame) navigation away from this
                // Canvas's own local page — a tapped link, window.location,
                // a form submit, whatever triggers it — is always blocked,
                // completely independent of the Internet toggle below.
                // There is no setting, no toggle, no state this Canvas can
                // reach that makes Canva Player navigate somewhere else.
                // The Internet toggle only ever affects sub-resource fetches
                // (fetch/XHR/images/fonts/etc.) handled in
                // shouldInterceptRequest — never top-level navigation.
                if (url.host != ASSET_DOMAIN) {
                    Toast.makeText(this@CanvasViewerActivity, R.string.external_link_blocked, Toast.LENGTH_SHORT).show()
                    return true
                }
                return false
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    showErrorState()
                }
            }
        }
    }

    private fun loadCanvas() {
        hideErrorState()
        binding.webView.loadUrl(startUrl)
    }

    // ---------------------------------------------------------------------
    // Export / download capture
    //
    // A Canvas's own "Export" or "Download" button almost always works by
    // creating a blob: URL and clicking a hidden <a download> link. Regular
    // WebViews have no UI for that, so we catch it here, pull the bytes back
    // out of the page's JS context, and hand the user a normal Android
    // "Save as" dialog — turning a CSV export into a real .xlsx along the way.
    // ---------------------------------------------------------------------

    private fun handleDownload(url: String, contentDisposition: String?, mimeType: String?) {
        val suggestedName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        when {
            url.startsWith("data:") -> handleDataUri(url, suggestedName)
            url.startsWith("blob:") -> fetchBlobViaJs(url, suggestedName, mimeType)
            url.startsWith("http:") || url.startsWith("https:") -> {
                if (!project.internetEnabled) {
                    Toast.makeText(this, R.string.internet_off_desc, Toast.LENGTH_SHORT).show()
                    return
                }
                fetchHttpDownload(url, suggestedName, mimeType)
            }
            else -> Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleDataUri(dataUri: String, suggestedName: String) {
        try {
            val comma = dataUri.indexOf(',')
            if (comma < 0) return
            val meta = dataUri.substring(5, comma) // strip "data:"
            val payload = dataUri.substring(comma + 1)
            val isBase64 = meta.endsWith(";base64")
            val mime = meta.removeSuffix(";base64").ifBlank { "application/octet-stream" }
            val bytes = if (isBase64) {
                Base64.decode(payload, Base64.DEFAULT)
            } else {
                java.net.URLDecoder.decode(payload, "UTF-8").toByteArray(Charsets.UTF_8)
            }
            processExportedBytes(bytes, suggestedName, mime)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchBlobViaJs(blobUrl: String, suggestedName: String, mimeType: String?) {
        val escapedUrl = blobUrl.replace("\\", "\\\\").replace("\"", "\\\"")
        val escapedName = suggestedName.replace("\\", "\\\\").replace("\"", "\\\"")
        val fallbackMime = mimeType ?: "application/octet-stream"
        val js = """
            (function() {
              fetch("$escapedUrl")
                .then(function(r) { return r.blob(); })
                .then(function(blob) {
                  var reader = new FileReader();
                  reader.onloadend = function() {
                    var dataUrl = reader.result;
                    var idx = dataUrl.indexOf(',');
                    var base64 = idx >= 0 ? dataUrl.substring(idx + 1) : '';
                    AndroidExport.onBlobReady(base64, "$escapedName", blob.type || "$fallbackMime");
                  };
                  reader.readAsDataURL(blob);
                })
                .catch(function(e) { AndroidExport.onBlobError(String(e)); });
            })();
        """.trimIndent()
        binding.webView.evaluateJavascript(js, null)
    }

    private fun fetchHttpDownload(url: String, suggestedName: String, mimeType: String?) {
        thread {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.instanceFollowRedirects = true
                connection.connectTimeout = 15_000
                connection.readTimeout = 15_000
                connection.connect()

                if (connection.responseCode !in 200..299) {
                    runOnUiThread { Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show() }
                    return@thread
                }

                val resolvedMime = connection.contentType ?: mimeType ?: "application/octet-stream"
                val bytes = connection.inputStream.use { input ->
                    val buffer = java.io.ByteArrayOutputStream()
                    val chunk = ByteArray(8 * 1024)
                    var total = 0L
                    var read = input.read(chunk)
                    while (read >= 0) {
                        total += read
                        if (total > MAX_HTTP_DOWNLOAD_BYTES) {
                            throw java.io.IOException("Download too large")
                        }
                        buffer.write(chunk, 0, read)
                        read = input.read(chunk)
                    }
                    buffer.toByteArray()
                }
                runOnUiThread { processExportedBytes(bytes, suggestedName, resolvedMime) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show() }
            }
        }
    }

    /**
     * If the exported bytes look like CSV (the common case for a Canvas's
     * "Export for Excel" button), convert them into a genuine .xlsx workbook.
     * Anything else is handed to the user exactly as the Canvas produced it.
     */
    private fun processExportedBytes(bytes: ByteArray, suggestedName: String, mimeType: String) {
        val looksLikeCsv = mimeType.contains("csv", ignoreCase = true) ||
            suggestedName.endsWith(".csv", ignoreCase = true)

        if (looksLikeCsv) {
            try {
                val csvText = String(bytes, Charsets.UTF_8)
                val rows = XlsxWriter.rowsFromCsv(csvText)
                val xlsxBytes = XlsxWriter.write(rows)
                val xlsxName = suggestedName.substringBeforeLast('.', suggestedName) + ".xlsx"
                pendingExportBytes = xlsxBytes
                pendingExportName = xlsxName
                saveXlsxLauncher.launch(xlsxName)
                return
            } catch (e: Exception) {
                // Fall through and save the original bytes if conversion fails.
            }
        }

        pendingExportBytes = bytes
        pendingExportName = suggestedName
        saveGenericLauncher.launch(suggestedName)
    }

    private fun writePendingExport(uri: android.net.Uri?) {
        val bytes = pendingExportBytes
        if (uri == null || bytes == null) {
            pendingExportBytes = null
            pendingExportName = null
            return
        }
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, R.string.export_saved, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        } finally {
            pendingExportBytes = null
            pendingExportName = null
        }
    }

    /** Minimal, single-purpose JS bridge used only to receive exported file bytes. */
    private inner class ExportBridge {
        @JavascriptInterface
        fun onBlobReady(base64Data: String, suggestedName: String, mimeType: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    processExportedBytes(bytes, suggestedName, mimeType)
                } catch (e: Exception) {
                    Toast.makeText(this@CanvasViewerActivity, R.string.import_failed, Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun onBlobError(message: String) {
            runOnUiThread {
                Toast.makeText(this@CanvasViewerActivity, R.string.import_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------------
    // Top bar controls
    // ---------------------------------------------------------------------

    private fun setupTopBar() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnReload.setOnClickListener { loadCanvas() }
        binding.internetToggle.setOnClickListener { toggleInternet() }
        updateInternetUi()

        binding.btnErrorBack.setOnClickListener { finish() }
        binding.btnErrorRetry.setOnClickListener { loadCanvas() }
    }

    private fun toggleInternet() {
        project.internetEnabled = !project.internetEnabled
        repository.update(project)
        updateInternetUi()
        val messageRes = if (project.internetEnabled) R.string.internet_on_desc else R.string.internet_off_desc
        Toast.makeText(this, messageRes, Toast.LENGTH_SHORT).show()
        // Reload so the new permission state applies cleanly to fresh requests.
        loadCanvas()
    }

    private fun updateInternetUi() {
        if (project.internetEnabled) {
            binding.imgInternet.setImageResource(R.drawable.ic_wifi_on)
            binding.internetToggle.setBackgroundResource(R.drawable.bg_pill_toggle_on)
        } else {
            binding.imgInternet.setImageResource(R.drawable.ic_wifi_off)
            binding.internetToggle.setBackgroundResource(R.drawable.bg_pill_toggle_off)
        }
    }

    // ---------------------------------------------------------------------
    // Error state
    // ---------------------------------------------------------------------

    private fun showErrorState() {
        binding.errorState.visibility = View.VISIBLE
        binding.webContainer.visibility = View.GONE
    }

    private fun hideErrorState() {
        binding.errorState.visibility = View.GONE
        binding.webContainer.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------------
    // Back button: internal WebView history first, then close the Canvas.
    // ---------------------------------------------------------------------

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    override fun onDestroy() {
        binding.webView.apply {
            stopLoading()
            clearHistory()
            destroy()
        }
        super.onDestroy()
    }
}
