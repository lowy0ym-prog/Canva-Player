package com.canvaplayer.app.data

import android.content.Context
import com.canvaplayer.app.model.CanvasProject
import org.json.JSONArray
import java.io.File

/**
 * Very small local-only persistence layer.
 *
 * All Canvas metadata lives in a single JSON file inside the app's private
 * storage (`filesDir/library.json`). There is no network, no account, and no
 * cloud sync involved anywhere in this class — everything is read from and
 * written to disk on the device.
 */
class CanvasRepository private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val libraryFile = File(appContext.filesDir, "library.json")

    /** Root directory that holds one sub-folder per imported Canvas project. */
    val canvasesRootDir: File = File(appContext.filesDir, "canvases").apply { mkdirs() }

    private val projects = mutableListOf<CanvasProject>()

    init {
        load()
    }

    @Synchronized
    fun getAll(): List<CanvasProject> = projects.toList()

    @Synchronized
    fun getById(id: String): CanvasProject? = projects.find { it.id == id }

    @Synchronized
    fun add(project: CanvasProject) {
        projects.add(project)
        persist()
    }

    @Synchronized
    fun update(project: CanvasProject) {
        val index = projects.indexOfFirst { it.id == project.id }
        if (index >= 0) {
            projects[index] = project
            persist()
        }
    }

    @Synchronized
    fun delete(project: CanvasProject) {
        projects.removeAll { it.id == project.id }
        persist()
        // Best-effort cleanup of the project's files on disk.
        File(canvasesRootDir, project.folderName).deleteRecursively()
    }

    fun projectDir(project: CanvasProject): File = File(canvasesRootDir, project.folderName)

    private fun load() {
        projects.clear()
        if (!libraryFile.exists()) return
        try {
            val text = libraryFile.readText()
            if (text.isBlank()) return
            val array = JSONArray(text)
            for (i in 0 until array.length()) {
                projects.add(CanvasProject.fromJson(array.getJSONObject(i)))
            }
        } catch (e: Exception) {
            // Corrupt library file — start fresh rather than crashing the app.
            projects.clear()
        }
    }

    @Synchronized
    private fun persist() {
        val array = JSONArray()
        projects.forEach { array.put(it.toJson()) }
        try {
            libraryFile.writeText(array.toString())
        } catch (e: Exception) {
            // Disk write failed; nothing further we can safely do here.
        }
    }

    companion object {
        @Volatile private var instance: CanvasRepository? = null

        fun getInstance(context: Context): CanvasRepository =
            instance ?: synchronized(this) {
                instance ?: CanvasRepository(context).also { instance = it }
            }
    }
}
