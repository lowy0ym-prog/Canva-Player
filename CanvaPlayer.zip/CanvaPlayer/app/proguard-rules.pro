# Canva Player - keep WebView JS interface members (none exposed currently, kept for safety)
-keepclassmembers class com.canvaplayer.app.** {
   public *;
}
