@rem
@rem Standard Gradle wrapper launch script for Windows.
@rem See README.md ("About the Gradle wrapper") — gradle-wrapper.jar is not
@rem bundled in this archive and must be regenerated locally first.
@rem
@echo off
setlocal

set DIRNAME=%~dp0
set APP_HOME=%DIRNAME%

set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

if not exist "%CLASSPATH%" (
  echo ERROR: %CLASSPATH% not found.
  echo Run "gradle wrapper" with a local Gradle install ^(or open this project
  echo in Android Studio^) to regenerate it, then re-run gradlew.bat.
  exit /b 1
)

if defined JAVA_HOME (
  set JAVA_EXE=%JAVA_HOME%\bin\java.exe
) else (
  set JAVA_EXE=java.exe
)

"%JAVA_EXE%" -Xmx64m -Xms64m -Dorg.gradle.appname=Gradle -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

endlocal
