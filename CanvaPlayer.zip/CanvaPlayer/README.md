# Canva Player

A dedicated Android app for **running and interacting with** AI-generated
HTML/CSS/JS "Canvases" — buttons, menus, forms, drag-and-drop, animations,
`localStorage`, all of it — without ever turning into a general-purpose web
browser.

This is not a browser. There is no address bar, no search engine, no way to
type an arbitrary URL, and no way to navigate to the open web from inside a
Canvas. The WebView is purely an internal engine for playing back HTML
projects you import.

---

## Features

- **My Canvases** home library: rounded cards, search (local only — never
  touches the internet), Favorites/Recent filters, sort by name / date added
  / last opened. Search lives in a floating bottom pill bar (One UI 8.5's
  "search moved to the bottom" direction) instead of a top app-bar icon.
- **Import HTML** — pick a single `.html`/`.htm` file; it's copied into the
  app's private storage.
- **Import ZIP** — pick a `.zip` containing `index.html` + CSS/JS/images/
  fonts/assets; it's extracted preserving its folder structure, with
  zip-slip / path-traversal protection built in.
- **Open directly from a file manager** — tapping a `.html`/`.htm`/`.zip`
  file anywhere on the device and choosing "Canva Player" from the system
  "Open with…" sheet imports it into the library and opens it immediately,
  no need to go through "Add Canvas" first.
- **Canvas Viewer** — near full-screen WebView with a slim top bar
  (Back · Name · Reload · Internet toggle). Full read/write interaction:
  taps, forms, `contenteditable` fields, drag-and-drop, animations, and
  `localStorage`/IndexedDB all work exactly as the Canvas was built.
- **Real Excel export** — when a Canvas's own "Export"/"Download" button
  produces a CSV (the common case, exactly like the sample family/event
  call-list Canvas's "Export for Excel" button), Canva Player automatically
  converts it into a genuine `.xlsx` workbook and hands you Android's normal
  "Save as" picker. Non-CSV exports (images, JSON, etc.) are saved as-is.
  This works generically for any Canvas that triggers a download — not just
  one specific file.
- **Per-Canvas Internet toggle** — off by default. When off, HTTP/HTTPS
  sub-resource requests are blocked while all local HTML/CSS/JS/assets keep
  working normally, even in airplane mode. When on, the Canvas can reach the
  network for things like remote fonts or APIs — but top-level navigation to
  an external page is *always* blocked; Canva Player never opens a browser.
- **Offline-first** — everything after import lives on-device; no account,
  no cloud, no Google Play Services dependency.
- **Light / Dark / Follow system** appearance, persisted.
- **Built-in Test Canvas** — a small bundled HTML/CSS/JS demo (tap button,
  `localStorage` counter, CSS animation, drag-and-drop) so you can instantly
  confirm the engine is really executing interactive HTML.
- **One UI 8.5–inspired UI** — floating, fully-rounded bottom sheets instead
  of hard-docked ones, a bottom-anchored search pill for one-handed reach,
  large rounded cards, big touch targets — no proprietary Samsung assets
  used anywhere.

## Project structure

```
CanvaPlayer/
├── app/
│   ├── src/main/java/com/canvaplayer/app/
│   │   ├── MainActivity.kt            # "My Canvases" library screen
│   │   ├── CanvasViewerActivity.kt    # WebView player + export capture
│   │   ├── ImportEntryActivity.kt     # "Open with Canva Player" router
│   │   ├── SettingsActivity.kt        # Light/Dark/System picker
│   │   ├── CanvasLibraryAdapter.kt    # RecyclerView adapter for cards
│   │   ├── CanvaPlayerApp.kt          # Application class, seeds test Canvas
│   │   ├── model/CanvasProject.kt     # Data model
│   │   ├── data/CanvasRepository.kt   # Local JSON-backed persistence
│   │   ├── importer/HtmlImporter.kt   # Copies a single HTML file in
│   │   └── importer/ZipImporter.kt    # Secure ZIP extraction
│   │   └── util/                      # FileUtils, ThemeManager, XlsxWriter
│   ├── src/main/res/                  # Layouts, drawables, themes, strings
│   ├── src/main/assets/testcanvas/    # Bundled sample interactive Canvas
│   └── build.gradle.kts
├── .github/workflows/build-apk.yml    # CI build → debug APK artifact
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── gradlew / gradlew.bat
└── local.properties.example
```

## Building

### Easiest: Android Studio
1. Open the `CanvaPlayer/` folder as a project in a recent Android Studio.
2. Let it sync Gradle (it will auto-generate `gradle-wrapper.jar`).
3. Run on a device/emulator, or **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.

### Command line
```bash
cd CanvaPlayer
cp local.properties.example local.properties   # then set sdk.dir
./gradlew assembleDebug
```
The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

### About the Gradle wrapper
This archive includes `gradlew` / `gradlew.bat` and
`gradle/wrapper/gradle-wrapper.properties`, but **not** the small binary
`gradle-wrapper.jar` — it was produced in a sandboxed, network-disabled
environment that couldn't download it. Before using `./gradlew` directly,
either:
- open the project once in Android Studio (it regenerates the jar
  automatically), or
- run `gradle wrapper` with any locally installed Gradle 8.x.

The included **GitHub Actions workflow does not need this jar at all** — it
installs Gradle 8.7 itself via `gradle/actions/setup-gradle` and builds with
that directly, so pushing this repo to GitHub and running the workflow (or
triggering it manually) will always produce a working debug APK.

### GitHub Actions
`.github/workflows/build-apk.yml` runs on every push/PR to `main`/`master`
and can also be triggered manually (`workflow_dispatch`). It checks out the
repo, sets up JDK 17 + Android SDK + Gradle 8.7, builds `assembleDebug`, and
uploads the resulting APK as a workflow artifact named
`canva-player-debug-apk`.

## The "no browser, ever" guarantee

There is no toggle, setting, or Canvas behavior anywhere in this app that
turns it into a browser. Specifically:

- **Top-level navigation to anywhere outside the Canvas's own local page is
  always blocked** — a tapped link, `window.location = "..."`, a form
  submit, anything. This is enforced in `shouldOverrideUrlLoading` and does
  **not** depend on the Internet toggle at all; it's blocked whether the
  toggle is on or off.
- **No new windows or tabs can ever open.** `window.open()` and
  `target="_blank"` links are disabled at the WebView settings level
  (`javaScriptCanOpenWindowsAutomatically`, `setSupportMultipleWindows`) and
  refused again at `onCreateWindow` — two independent layers, so this isn't
  resting on a single setting.
- **The Internet toggle only ever affects sub-resource fetches** — things
  like `fetch()`/XHR calls, remote images, or remote fonts a Canvas's own
  script makes *while running*, not navigation. Turning it on lets a Canvas
  reach the network for things it genuinely needs (e.g. an API call); it
  never grants the ability to browse anywhere.
- **Exporting to Excel needs no internet at all.** The CSV → `.xlsx` capture
  works entirely offline — it reads the file straight out of the page's own
  JavaScript (a `blob:` or `data:` URL) and writes it to your device with no
  network involved. You can turn Internet off for a Canvas like the sample
  Event Call List and its export button will still work. The Internet
  toggle would only matter if a Canvas's export specifically triggered a
  real `https://` download from a server — an uncommon case, and even then
  only that one download is allowed, never general browsing.
- There is no address bar, no URL input, and no search field anywhere in
  the app — there is simply no UI surface a Canvas or a user could use to
  type or trigger arbitrary browsing even if the above protections didn't
  exist.

## How the WebView is locked down

- Local project files are served through `androidx.webkit.WebViewAssetLoader`
  at `https://appassets.androidplatform.net/canvas/…` rather than raw
  `file://` URLs — this is the security-recommended way to let a WebView load
  local HTML/CSS/JS/images while keeping `allowFileAccess` disabled.
- `shouldInterceptRequest` blocks any `http://`/`https://` sub-resource
  request when the per-Canvas Internet toggle is off, while local asset
  requests always succeed.
- `shouldOverrideUrlLoading` blocks **all** top-level navigation to anything
  outside the Canvas's own local domain — links can never open a browser or
  navigate the WebView to an arbitrary external site.
- ZIP extraction rejects absolute paths, drive letters, and `..` segments,
  and double-checks every entry's resolved canonical path is still inside the
  destination project folder before writing anything to disk.
- The only JavaScript bridge exposed to a Canvas (`AndroidExport`) has
  exactly two methods, both write-only from the page's point of view: hand
  Android some file bytes to save, or report that a blob read failed. It
  cannot read anything back from Android, and no other Android API is
  reachable from a Canvas's JavaScript.
- `ImportEntryActivity` (the file-manager entry point) only ever accepts a
  single local file Uri the system hands it, imports that one file exactly
  like the in-app "Add Canvas" flow, and opens the sandboxed viewer — it
  never becomes a general document/URL handler.

## How Excel export works

Most AI-generated "export" buttons work the same way under the hood: build a
CSV or JSON string, wrap it in a `Blob`, create a `blob:` URL for it, and
click a hidden `<a download>` link. A plain WebView has no UI for that at
all — the click just silently does nothing visible.

Canva Player's viewer:
1. Catches that download via `WebView.setDownloadListener`.
2. For a `blob:` URL, injects a small script that re-fetches the blob from
   inside the page and hands the bytes back to Android as base64.
3. A document-start script also delays `URL.revokeObjectURL()` by a few
   seconds so a Canvas that revokes the blob immediately after triggering
   the download (as many do) can't race ahead of step 2.
4. If the resulting file looks like CSV, it's parsed and rewritten as a
   genuine `.xlsx` workbook (`util/XlsxWriter.kt` — a small, dependency-free
   OOXML writer, no Apache POI needed) before the save dialog appears.
5. Android's standard "Save as" (Storage Access Framework) dialog opens so
   you pick where the file goes — no storage permission required.

This is generic: it works for any Canvas's own export/download button, not
just one specific file.

## Notes / things to double-check

- This project was built file-by-file in a sandbox without Android SDK/
  Gradle available to actually compile it. Every layout was validated as
  well-formed XML, and every `R.id` / `R.string` / `R.drawable` / `R.style`
  reference used from Kotlin (including all ViewBinding field accesses) was
  cross-checked by script against the actual resources — but a first real
  Gradle build (Android Studio or CI) is still the authoritative check.
- The blob-download capture relies on `WebViewFeature.DOCUMENT_START_SCRIPT`
  and modern WebView support for `DownloadListener` firing on `blob:` URLs.
  Both are present on current, Play Store–updated System WebView (which is
  what real Samsung/Android devices ship). Canva Player checks
  `WebViewFeature.isFeatureSupported(...)` first and degrades gracefully
  (skips the revoke-delay patch) if it isn't available, rather than crashing.
- Minimum SDK 24 (Android 7.0), target/compile SDK 34, Kotlin 1.9.24, AGP
  8.5.2 — adjust versions in `build.gradle.kts` / `app/build.gradle.kts` if
  your environment needs something different.
- The app icon is an original design (a rounded "canvas frame" with a play
  triangle) and uses no Canva or Samsung trademarks or assets. The One UI
  8.5 direction (floating fully-rounded sheets, bottom-anchored search) is
  based on Samsung's own May 2026 rollout coverage, not any bundled Samsung
  code or graphics.
