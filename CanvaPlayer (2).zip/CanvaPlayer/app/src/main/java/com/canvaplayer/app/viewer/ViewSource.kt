package com.canvaplayer.app.viewer

import android.content.Context
import com.canvaplayer.app.util.FileUtils
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/** A folder to serve plus the page inside it to show first. */
data class Prepared(val rootDir: File, val entry: String, val title: String)

/**
 * Turns any supported file into something the viewer can show, WITHOUT adding
 * it to any library: nothing is saved permanently. Generated pages live in
 * the app's cache folder (Android may clear it at any time; it is rebuilt on
 * demand). Call from a background thread — extraction can take a moment.
 */
object ViewSource {

    private const val MAX_UNZIPPED = 400L * 1024 * 1024

    fun prepare(context: Context, file: File): Prepared? {
        val ext = file.extension.lowercase()
        val title = FileUtils.nameWithoutExtension(file.name).ifBlank { file.name }
        return when (ext) {
            "html", "htm" -> {
                // Serve the file's own folder so linked pages, CSS, JS and
                // images sitting next to it all work with relative links.
                val parent = file.parentFile ?: return null
                Prepared(parent, file.name, if (file.name.equals("index.html", true)) parent.name.ifBlank { title } else title)
            }
            "zip" -> prepareZip(context, file, title)
            "md", "markdown" -> preparePage(context, file, "md", "markdown.html", title, readCapped(file))
            "glb", "gltf" -> prepareWithViewer(context, file, "viewer3d", title)
            "geojson" -> prepareWithViewer(context, file, "geoviewer", title)
            "ttf", "otf", "woff", "woff2" -> prepareFont(context, file, ext, title)
            "csv", "tsv" -> preparePage(context, file, "csv", "csv.html", title, readCapped(file),
                mapOf("__SEP__" to if (ext == "tsv") "\\t" else "auto"))
            "json" -> preparePage(context, file, "json", "json.html", title, readCapped(file))
            "svg" -> {
                val parent = file.parentFile ?: return null
                Prepared(parent, file.name, title)
            }
            "css", "js", "txt", "log", "ini", "conf", "xml", "yaml", "yml", "srt" -> {
                val dir = cacheDirFor(context, file, "code")
                val page = File(dir, "index.html")
                if (!page.exists()) {
                    dir.mkdirs()
                    page.writeText(CodeViewerPage.toHtml(file.name, file.length(), readCapped(file)))
                }
                Prepared(dir, "index.html", file.name)
            }
            else -> null
        }
    }

    /** Fills one of the page templates in assets/pages and caches the result. */
    private fun preparePage(
        context: Context, file: File, kind: String, template: String, title: String,
        data: String, extra: Map<String, String> = emptyMap()
    ): Prepared {
        val dir = cacheDirFor(context, file, kind)
        val page = File(dir, "index.html")
        if (!page.exists()) {
            dir.mkdirs()
            page.writeText(render(context, template, title, data, extra))
        }
        return Prepared(dir, "index.html", title)
    }

    private fun render(
        context: Context, template: String, title: String, data: String, extra: Map<String, String>
    ): String {
        val css = context.assets.open("pages/base.css").bufferedReader().use { it.readText() }
        var html = context.assets.open("pages/$template").bufferedReader().use { it.readText() }
        html = html.replace("/*BASE_CSS*/", css).replace("__TITLE__", escHtml(title))
        for ((k, v) in extra) html = html.replace(k, v)
        // The file's own text goes in last, as a JS string literal, so nothing in it is ever read as markup.
        return html.replace("__DATA__", JSONObject.quote(data).replace("</", "<\\/"))
    }

    private fun escHtml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun prepareFont(context: Context, file: File, ext: String, title: String): Prepared {
        val dir = cacheDirFor(context, file, "font")
        val page = File(dir, "index.html")
        if (!page.exists()) {
            dir.mkdirs()
            val fontName = "font.$ext"
            file.inputStream().use { i -> File(dir, fontName).outputStream().use { i.copyTo(it) } }
            val format = when (ext) { "otf" -> "opentype"; "woff" -> "woff"; "woff2" -> "woff2"; else -> "truetype" }
            val meta = "${ext.uppercase()} font · ${FileUtils.humanReadableSize(file.length())}"
            page.writeText(
                render(context, "font.html", title, "", mapOf(
                    "__FONTFILE__" to fontName, "__FORMAT__" to format, "__META__" to meta
                ))
            )
        }
        return Prepared(dir, "index.html", title)
    }

    private fun readCapped(file: File): String {
        val max = 2_000_000
        val bytes = file.inputStream().use { it.readNBytesCompat(max + 1) }
        val text = bytes.toString(Charsets.UTF_8)
        return if (bytes.size > max) text.substring(0, max) + "\n\n… (file continues — showing the first 2 MB)" else text
    }

    private fun java.io.InputStream.readNBytesCompat(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (total < limit) {
            val n = read(buf, 0, minOf(buf.size, limit - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }

    private fun prepareWithViewer(context: Context, file: File, assetRoot: String, title: String): Prepared? {
        val dir = cacheDirFor(context, file, assetRoot)
        val marker = File(dir, ".ready")
        if (!marker.exists()) {
            dir.deleteRecursively()
            dir.mkdirs()
            copyAssets(context, assetRoot, dir)
            file.inputStream().use { input -> File(dir, "model.bin").outputStream().use { input.copyTo(it) } }
            marker.writeText("ok")
        }
        return Prepared(dir, "index.html", title)
    }

    private fun prepareZip(context: Context, file: File, title: String): Prepared? {
        val dir = cacheDirFor(context, file, "zip")
        val marker = File(dir, ".ready")
        if (!marker.exists()) {
            dir.deleteRecursively()
            dir.mkdirs()
            if (!extract(file, dir)) {
                dir.deleteRecursively()
                return null
            }
            marker.writeText("ok")
        }
        val entry = FileUtils.findEntryHtml(dir) ?: return null
        return Prepared(dir, entry, title)
    }

    /** Extracts with zip-slip protection; returns false for unsafe or oversized archives. */
    private fun extract(zipFile: File, dest: File): Boolean {
        val destCanonical = dest.canonicalFile
        var total = 0L
        try {
            ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    val skip = name.startsWith("__MACOSX/") || name.endsWith(".DS_Store")
                    if (!skip) {
                        if (name.startsWith("/") || name.contains(":") ||
                            name.split("/").any { it == ".." }
                        ) return false
                        val out = File(destCanonical, name).canonicalFile
                        if (out.path != destCanonical.path && !out.path.startsWith(destCanonical.path + File.separator)) {
                            return false
                        }
                        if (entry.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            BufferedOutputStream(FileOutputStream(out)).use { o ->
                                val buf = ByteArray(16 * 1024)
                                var n = zip.read(buf)
                                while (n >= 0) {
                                    total += n
                                    if (total > MAX_UNZIPPED) return false
                                    o.write(buf, 0, n)
                                    n = zip.read(buf)
                                }
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } catch (e: Exception) {
            return false
        }
        return true
    }

    /** Stable cache folder for one file version (path + size + modified time). */
    private fun cacheDirFor(context: Context, file: File, kind: String): File {
        val key = "${file.absolutePath}|${file.length()}|${file.lastModified()}|$kind"
        val hash = MessageDigest.getInstance("SHA-1").digest(key.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(16)
        return File(File(context.cacheDir, "view"), "$kind-$hash")
    }
}

/** Which files Canva Player can show, and how an arbitrary Uri becomes a local file. */
object SupportedFiles {
    val EXTENSIONS: Set<String> get() = FileKinds.EXTENSIONS

    fun extensionFromMime(mime: String?): String? = when (mime?.lowercase()) {
        "text/html" -> "html"
        "application/zip", "application/x-zip-compressed" -> "zip"
        "text/markdown", "text/x-markdown" -> "md"
        "model/gltf-binary" -> "glb"
        "model/gltf+json" -> "gltf"
        "application/geo+json", "application/vnd.geo+json" -> "geojson"
        "text/css" -> "css"
        "text/javascript", "application/javascript" -> "js"
        "font/ttf", "application/x-font-ttf", "application/x-font-truetype" -> "ttf"
        "font/otf", "application/x-font-otf", "application/vnd.ms-opentype", "application/font-sfnt" -> "otf"
        "font/woff", "application/font-woff", "application/x-font-woff" -> "woff"
        "font/woff2", "application/font-woff2" -> "woff2"
        "text/csv", "application/csv" -> "csv"
        "text/tab-separated-values" -> "tsv"
        "application/json" -> "json"
        "image/svg+xml" -> "svg"
        "text/plain" -> "txt"
        else -> null
    }

    /**
     * Gives the viewer a real file for [uri]. file:// Uris are used in place; content:// Uris are copied
     * to the app's cache (temporary — never added to any library). Call off the main thread.
     */
    fun toLocalFile(context: Context, uri: android.net.Uri, displayName: String, extension: String): File? {
        if (uri.scheme == "file") {
            val f = uri.path?.let { File(it) }
            if (f != null && f.isFile && f.canRead()) return f
        }
        return try {
            val root = File(context.cacheDir, "open")
            // Tidy up copies from earlier opens (older than an hour).
            root.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.deleteRecursively() }
            val dir = File(root, java.util.UUID.randomUUID().toString().take(10)).apply { mkdirs() }
            val safeName = displayName.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file.$extension" }
            val named = if (safeName.lowercase().endsWith(".$extension")) safeName else "$safeName.$extension"
            val out = File(dir, named)
            context.contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { input.copyTo(it) }
            } ?: return null
            out
        } catch (e: Exception) {
            null
        }
    }

    /** Deletes cached pages that haven't been touched for a week. */
    fun pruneCache(context: Context) {
        val limit = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        for (name in listOf("view", "open")) {
            File(context.cacheDir, name).listFiles()?.forEach { if (it.lastModified() < limit) it.deleteRecursively() }
        }
    }
}

private fun copyAssets(context: Context, assetPath: String, dest: File) {
        val children = context.assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            context.assets.open(assetPath).use { input -> dest.outputStream().use { input.copyTo(it) } }
            return
        }
        dest.mkdirs()
        for (child in children) copyAssets(context, "$assetPath/$child", File(dest, child))
    }
