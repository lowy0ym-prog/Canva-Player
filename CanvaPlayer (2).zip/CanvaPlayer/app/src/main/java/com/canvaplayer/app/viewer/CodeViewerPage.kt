package com.canvaplayer.app.viewer

import com.canvaplayer.app.util.FileUtils

/** Read-only, line-numbered page for .css / .js files. No scripts from the file ever run. */
object CodeViewerPage {

    fun toHtml(fileName: String, sizeBytes: Long, text: String): String {
        val body = StringBuilder()
        var n = 1
        for (line in text.replace("\r\n", "\n").split("\n")) {
            body.append("<span class=\"l\" data-n=\"").append(n++).append("\">")
                .append(esc(line)).append("</span>\n")
        }
        return """<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(fileName)}</title>
<style>
:root{color-scheme:light dark}
body{margin:0;font:13px/1.5 ui-monospace,Menlo,Consolas,monospace}
header{position:sticky;top:0;display:flex;gap:10px;align-items:center;padding:8px 12px;
 background:rgba(127,127,127,.18);backdrop-filter:blur(6px);font:600 13px system-ui,sans-serif}
header span{opacity:.65;font-weight:400}
header button{margin-left:auto;font:inherit;padding:4px 10px;border-radius:8px;border:1px solid rgba(127,127,127,.5);background:transparent;color:inherit}
pre{margin:0;padding:8px 0;overflow:auto;white-space:pre}
pre.wrap{white-space:pre-wrap;word-break:break-all}
.l{display:block;padding:0 12px 0 54px;position:relative;min-height:1.5em}
.l::before{content:attr(data-n);position:absolute;left:0;width:44px;text-align:right;opacity:.45}
</style></head><body>
<header>${esc(fileName)} <span>${FileUtils.humanReadableSize(sizeBytes)}</span>
<button onclick="document.getElementById('c').classList.toggle('wrap')">Wrap lines</button></header>
<pre id="c">${body}</pre>
</body></html>"""
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}
