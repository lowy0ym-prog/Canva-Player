package com.canvaplayer.app.util

/**
 * Small, dependency-free Markdown -> HTML converter (headings, emphasis,
 * code, lists, quotes, rules, links, images, simple tables). All input is
 * HTML-escaped first, and no scripts are ever emitted. Links render as plain
 * text-styled spans: this app never navigates anywhere.
 */
object MarkdownRenderer {

    fun toHtmlPage(title: String, markdown: String): String = """<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title>
<style>
:root{color-scheme:light dark}
body{font:16px/1.6 system-ui,sans-serif;max-width:760px;margin:0 auto;padding:20px}
pre{background:rgba(127,127,127,.15);padding:12px;border-radius:8px;overflow:auto}
code{background:rgba(127,127,127,.15);padding:1px 5px;border-radius:4px}
pre code{background:none;padding:0}
blockquote{margin:0;padding-left:14px;border-left:4px solid rgba(127,127,127,.5);opacity:.85}
table{border-collapse:collapse}td,th{border:1px solid rgba(127,127,127,.5);padding:6px 10px}
img{max-width:100%}hr{border:0;border-top:1px solid rgba(127,127,127,.5)}
</style></head><body>
${render(markdown)}
</body></html>"""

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun inline(raw: String): String {
        var t = esc(raw)
        t = Regex("`([^`]+)`").replace(t) { "<code>${it.groupValues[1]}</code>" }
        t = Regex("!\\[([^\\]]*)\\]\\(([^)\\s]+)[^)]*\\)").replace(t) {
            val src = it.groupValues[2]
            // Only local/relative or data: images; remote URLs can't load anyway.
            if (src.startsWith("http", true)) esc(it.groupValues[1])
            else "<img alt=\"${it.groupValues[1]}\" src=\"$src\">"
        }
        t = Regex("\\[([^\\]]+)\\]\\(([^)]+)\\)").replace(t) { "<span>${it.groupValues[1]}</span>" }
        t = Regex("\\*\\*([^*]+)\\*\\*").replace(t) { "<strong>${it.groupValues[1]}</strong>" }
        t = Regex("(?<![*\\w])\\*([^*]+)\\*(?![*\\w])").replace(t) { "<em>${it.groupValues[1]}</em>" }
        t = Regex("~~([^~]+)~~").replace(t) { "<del>${it.groupValues[1]}</del>" }
        return t
    }

    private fun render(md: String): String {
        val lines = md.replace("\r\n", "\n").split("\n")
        val out = StringBuilder()
        var i = 0
        var listType: String? = null
        fun closeList() { listType?.let { out.append("</$it>\n") }; listType = null }

        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trim()
            when {
                trimmed.startsWith("```") -> {
                    closeList()
                    val code = StringBuilder()
                    i++
                    while (i < lines.size && !lines[i].trim().startsWith("```")) {
                        code.append(esc(lines[i])).append("\n"); i++
                    }
                    out.append("<pre><code>").append(code).append("</code></pre>\n")
                }
                trimmed.isEmpty() -> closeList()
                Regex("^#{1,6} .*").matches(trimmed) -> {
                    closeList()
                    val level = trimmed.takeWhile { it == '#' }.length
                    out.append("<h$level>${inline(trimmed.drop(level + 1))}</h$level>\n")
                }
                Regex("^(-{3,}|\\*{3,}|_{3,})$").matches(trimmed) -> { closeList(); out.append("<hr>\n") }
                trimmed.startsWith(">") -> {
                    closeList()
                    out.append("<blockquote>${inline(trimmed.removePrefix(">").trim())}</blockquote>\n")
                }
                Regex("^[-*+] .*").matches(trimmed) -> {
                    if (listType != "ul") { closeList(); out.append("<ul>\n"); listType = "ul" }
                    out.append("<li>${inline(trimmed.drop(2))}</li>\n")
                }
                Regex("^\\d+[.)] .*").matches(trimmed) -> {
                    if (listType != "ol") { closeList(); out.append("<ol>\n"); listType = "ol" }
                    out.append("<li>${inline(trimmed.substringAfter(' '))}</li>\n")
                }
                trimmed.startsWith("|") && i + 1 < lines.size &&
                    Regex("^\\|?[\\s:|-]+\\|[\\s:|-]*$").matches(lines[i + 1].trim()) -> {
                    closeList()
                    fun cells(l: String) = l.trim().trim('|').split("|").map { inline(it.trim()) }
                    out.append("<table><tr>")
                    cells(trimmed).forEach { out.append("<th>$it</th>") }
                    out.append("</tr>")
                    i += 2
                    while (i < lines.size && lines[i].trim().startsWith("|")) {
                        out.append("<tr>")
                        cells(lines[i]).forEach { out.append("<td>$it</td>") }
                        out.append("</tr>"); i++
                    }
                    out.append("</table>\n")
                    continue
                }
                else -> { closeList(); out.append("<p>${inline(trimmed)}</p>\n") }
            }
            i++
        }
        closeList()
        return out.toString()
    }
}
