package com.canvaplayer.app.importer

import android.content.Context
import android.net.Uri
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils
import java.io.File

/**
 * Imports a single-file 3D model (.glb, or a self-contained .gltf) as a
 * Canvas: the bundled offline viewer page + three.js are copied next to the
 * model into the project's private folder. No network is ever involved.
 * (.blend files must be exported from Blender as .glb first.)
 */
object ModelImporter {

    private const val ASSET_ROOT = "viewer3d"

    fun importModel(context: Context, uri: Uri, displayName: String): ImportResult {
        val repository = CanvasRepository.getInstance(context)
        val folderName = FileUtils.newProjectFolderName()
        val destDir = File(repository.canvasesRootDir, folderName)
        destDir.mkdirs()
        return try {
            copyAssets(context, ASSET_ROOT, destDir)
            val ok = context.contentResolver.openInputStream(uri)?.use { input ->
                File(destDir, "model.bin").outputStream().use { input.copyTo(it) }
                true
            } ?: false
            if (!ok) {
                destDir.deleteRecursively()
                return ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
            }
            val project = CanvasProject(
                name = FileUtils.nameWithoutExtension(displayName).ifBlank { "3D Model" },
                folderName = folderName,
                entryRelativePath = "index.html",
                sourceType = CanvasProject.SourceType.MODEL,
                sizeBytes = FileUtils.sizeOf(destDir)
            )
            repository.add(project)
            ImportResult.Success(project)
        } catch (e: Exception) {
            destDir.deleteRecursively()
            ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
        }
    }

    internal fun copyAssets(context: Context, assetPath: String, dest: File) {
        val children = context.assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            // A file, not a directory.
            context.assets.open(assetPath).use { input ->
                dest.outputStream().use { input.copyTo(it) }
            }
            return
        }
        dest.mkdirs()
        for (child in children) {
            copyAssets(context, "$assetPath/$child", File(dest, child))
        }
    }
}
