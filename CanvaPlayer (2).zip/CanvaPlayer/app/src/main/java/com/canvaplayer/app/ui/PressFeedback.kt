package com.canvaplayer.app.ui

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View

/** Instant "pressed" feedback: the control shrinks slightly while a finger is on it. */
object PressFeedback {
    @SuppressLint("ClickableViewAccessibility")
    fun apply(view: View, pressedScale: Float = 0.92f, target: View = view) {
        view.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    target.animate().scaleX(pressedScale).scaleY(pressedScale).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    target.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
    }
}
