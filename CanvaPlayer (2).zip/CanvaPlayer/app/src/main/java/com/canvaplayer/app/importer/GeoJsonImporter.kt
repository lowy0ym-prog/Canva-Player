package com.canvaplayer.app.importer

import android.content.Context
import android.net.Uri
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils
import java.io.File

/**
 * Imports a GeoJSON file (routes, areas, points) as a Canvas drawn by the
 * bundled offline map viewer. No map tiles / network are ever used.
 */
object GeoJsonImporter {

    private const val ASSET_ROOT = "geoviewer"

    fun importGeoJson(context: Context, uri: Uri, displayName: String): ImportResult {
        val repository = CanvasRepository.getInstance(context)
        val folderName = FileUtils.newProjectFolderName()
        val destDir = File(repository.canvasesRootDir, folderName)
        destDir.mkdirs()
        return try {
            ModelImporter.copyAssets(context, ASSET_ROOT, destDir)
            val ok = context.contentResolver.openInputStream(uri)?.use { input ->
                File(destDir, "model.bin").outputStream().use { input.copyTo(it) }
                true
            } ?: false
            if (!ok) {
                destDir.deleteRecursively()
                return ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
            }
            val project = CanvasProject(
                name = FileUtils.nameWithoutExtension(displayName).ifBlank { "Map" },
                folderName = folderName,
                entryRelativePath = "index.html",
                sourceType = CanvasProject.SourceType.GEOJSON,
                sizeBytes = FileUtils.sizeOf(destDir)
            )
            repository.add(project)
            ImportResult.Success(project)
        } catch (e: Exception) {
            destDir.deleteRecursively()
            ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
        }
    }
}
