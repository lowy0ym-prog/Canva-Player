package com.canvaplayer.app.library

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.model.CanvasProject.SourceType
import com.canvaplayer.app.util.FileUtils
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

/**
 * Finds the files Canva Player can show on the phone, like a gallery scans
 * for photos. Nothing is copied or imported — each result just points at the
 * original file. Entirely local; no network.
 *
 * To keep the library tidy it deliberately does NOT list:
 *  - every page of an unpacked website (only its index page is shown, as one
 *    entry named after the folder), nor that site's own CSS/JS/assets;
 *  - ZIPs that contain no web page (ordinary archives);
 *  - loose .css/.js files that sit next to HTML pages;
 *  - Android's private folders, hidden folders and node_modules.
 */
object DeviceScanner {

    private val EXTENSIONS = setOf("html", "htm", "zip", "md", "markdown", "glb", "gltf", "geojson", "css", "js")
    private val SKIP_DIRS = setOf("android", "node_modules", "lost.dir", "thumbnails", "cache")
    private const val MAX_DEPTH = 10

    fun hasAccess(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    fun scan(context: Context): List<CanvasProject> {
        val prefs = LibraryPrefs(context)
        val hidden = prefs.hidden()
        val out = mutableListOf<CanvasProject>()
        val root = Environment.getExternalStorageDirectory()
        walk(root, 0, prefs, out)
        return out.filter { it.devicePath !in hidden }
    }

    private fun walk(dir: File, depth: Int, prefs: LibraryPrefs, out: MutableList<CanvasProject>) {
        if (depth > MAX_DEPTH) return
        val children = dir.listFiles() ?: return

        val index = children.firstOrNull {
            it.isFile && (it.name.equals("index.html", true) || it.name.equals("index.htm", true))
        }
        if (index != null && depth >= 2) {
            // A website folder: show just its front page, don't dig inside.
            out.add(entryFor(index, SourceType.HTML, dir.name.ifBlank { "Website" }, prefs))
            return
        }
        val hasHtml = children.any { it.isFile && it.extension.lowercase() in setOf("html", "htm") }

        for (child in children) {
            val name = child.name
            if (name.startsWith(".")) continue
            if (child.isDirectory) {
                if (name.lowercase() in SKIP_DIRS) continue
                walk(child, depth + 1, prefs, out)
                continue
            }
            val ext = child.extension.lowercase()
            if (ext !in EXTENSIONS) continue
            when (ext) {
                "html", "htm" -> out.add(entryFor(child, SourceType.HTML, null, prefs))
                "zip" -> if (zipHoldsWebPage(child, prefs)) out.add(entryFor(child, SourceType.ZIP, null, prefs))
                "md", "markdown" -> out.add(entryFor(child, SourceType.MARKDOWN, null, prefs))
                "glb", "gltf" -> out.add(entryFor(child, SourceType.MODEL, null, prefs))
                "geojson" -> out.add(entryFor(child, SourceType.GEOJSON, null, prefs))
                "css" -> if (!hasHtml) out.add(entryFor(child, SourceType.CSS, null, prefs))
                "js" -> if (!hasHtml) out.add(entryFor(child, SourceType.JS, null, prefs))
            }
        }
    }

    private fun zipHoldsWebPage(file: File, prefs: LibraryPrefs): Boolean {
        val size = file.length()
        val modified = file.lastModified()
        prefs.zipIsCanvas(file.absolutePath, size, modified)?.let { return it }
        val result = try {
            ZipFile(file).use { zip ->
                zip.entries().asSequence().any {
                    val n = it.name.lowercase()
                    !it.isDirectory && !n.startsWith("__macosx/") && (n.endsWith(".html") || n.endsWith(".htm"))
                }
            }
        } catch (e: Exception) {
            false
        }
        prefs.rememberZip(file.absolutePath, size, modified, result)
        return result
    }

    private fun entryFor(file: File, type: SourceType, titleOverride: String?, prefs: LibraryPrefs): CanvasProject {
        val path = file.absolutePath
        val title = titleOverride
            ?: if (type == SourceType.CSS || type == SourceType.JS) file.name
            else FileUtils.nameWithoutExtension(file.name).ifBlank { file.name }
        return CanvasProject(
            id = "f:" + sha1(path),
            name = title,
            folderName = file.parentFile?.absolutePath.orEmpty(),
            entryRelativePath = file.name,
            dateAdded = file.lastModified(),
            lastOpened = prefs.lastOpened(path),
            favorite = prefs.isFavorite(path),
            sizeBytes = file.length(),
            sourceType = type,
            devicePath = path
        )
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)
}
