package com.canvaplayer.app.viewer

import com.canvaplayer.app.model.CanvasProject.SourceType

/** The single list of what this app can read. */
object FileKinds {
    private val map: Map<String, SourceType> = buildMap {
        listOf("html", "htm").forEach { put(it, SourceType.HTML) }
        put("zip", SourceType.ZIP)
        listOf("md", "markdown").forEach { put(it, SourceType.MARKDOWN) }
        listOf("glb", "gltf").forEach { put(it, SourceType.MODEL) }
        put("geojson", SourceType.GEOJSON)
        put("css", SourceType.CSS)
        put("js", SourceType.JS)
        listOf("ttf", "otf", "woff", "woff2").forEach { put(it, SourceType.FONT) }
        listOf("csv", "tsv", "json").forEach { put(it, SourceType.DATA) }
        listOf("txt", "log", "ini", "conf", "xml", "yaml", "yml", "srt").forEach { put(it, SourceType.TEXT) }
        put("svg", SourceType.SVG)
    }

    val EXTENSIONS: Set<String> get() = map.keys

    /** Extensions the automatic phone scan lists (plain text/JSON/XML would flood the library). */
    val SCANNED: Set<String> = setOf(
        "html", "htm", "zip", "md", "markdown", "glb", "gltf", "geojson", "css", "js",
        "ttf", "otf", "woff", "woff2", "csv", "tsv", "svg"
    )

    fun typeOf(ext: String): SourceType? = map[ext.lowercase()]

    fun label(type: SourceType): String = when (type) {
        SourceType.ZIP -> "ZIP project"
        SourceType.MARKDOWN -> "Markdown"
        SourceType.MODEL -> "3D model"
        SourceType.GEOJSON -> "Map"
        SourceType.CSS -> "CSS"
        SourceType.JS -> "JavaScript"
        SourceType.FONT -> "Font"
        SourceType.TEXT -> "Text"
        SourceType.DATA -> "Data"
        SourceType.SVG -> "Image"
        else -> "Web page"
    }
}
