package com.canvaplayer.app.importer

import android.content.Context
import android.net.Uri
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.util.MarkdownRenderer
import java.io.File

/** Renders a .md file to a styled local index.html and stores it as a Canvas. */
object MarkdownImporter {

    fun importMarkdown(context: Context, uri: Uri, displayName: String): ImportResult {
        val repository = CanvasRepository.getInstance(context)
        val folderName = FileUtils.newProjectFolderName()
        val destDir = File(repository.canvasesRootDir, folderName)
        destDir.mkdirs()
        return try {
            val text = context.contentResolver.openInputStream(uri)?.use {
                it.readBytes().toString(Charsets.UTF_8)
            } ?: run {
                destDir.deleteRecursively()
                return ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
            }
            val title = FileUtils.nameWithoutExtension(displayName).ifBlank { "Document" }
            File(destDir, "index.html").writeText(MarkdownRenderer.toHtmlPage(title, text))
            val project = CanvasProject(
                name = title,
                folderName = folderName,
                entryRelativePath = "index.html",
                sourceType = CanvasProject.SourceType.HTML,
                sizeBytes = FileUtils.sizeOf(destDir)
            )
            repository.add(project)
            ImportResult.Success(project)
        } catch (e: Exception) {
            destDir.deleteRecursively()
            ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
        }
    }
}
