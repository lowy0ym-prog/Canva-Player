package com.canvaplayer.app.thumbs

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.model.CanvasProject.SourceType
import com.canvaplayer.app.viewer.FileKinds
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Gallery-style previews. A preview is made once per file version, kept in memory
 * and on disk, and shown instantly next time. Everything is drawn locally.
 *
 *  - text, code, data, Markdown: the first lines drawn on a "paper" card
 *  - fonts: a big "Aa" in the font itself
 *  - maps (GeoJSON): the shapes drawn to scale
 *  - web pages, SVG, ZIP sites: a real snapshot taken by [WebThumbRenderer]
 */
object Thumbnails {

    private const val VERSION = 5
    @Volatile private var night = false
    private fun cBg() = Color.parseColor(if (night) "#1E1E1E" else "#FFFFFF")
    private fun cStrong() = Color.parseColor(if (night) "#F2F2F2" else "#0A0A0A")
    private fun cSoft() = Color.parseColor(if (night) "#B3B3B3" else "#555555")
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newFixedThreadPool(2)

    private val mem = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 12).toInt().coerceAtLeast(4 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    /** Set by the screen that owns the hidden WebView surface. */
    @Volatile var web: WebThumbRenderer? = null

    private fun dir(ctx: Context) = File(ctx.filesDir, "thumbs").apply { mkdirs() }

    private fun keyOf(file: File, size: Int): String {
        val raw = "${file.absolutePath}|${file.length()}|${file.lastModified()}|$size|$VERSION|$night"
        return MessageDigest.getInstance("SHA-1").digest(raw.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun clearAll(ctx: Context) {
        mem.evictAll()
        dir(ctx).deleteRecursively()
    }

    fun prune(ctx: Context) {
        try {
            val files = dir(ctx).listFiles()?.sortedBy { it.lastModified() } ?: return
            var total = files.sumOf { it.length() }
            for (f in files) {
                if (total <= 40L * 1024 * 1024) break
                total -= f.length()
                f.delete()
            }
        } catch (_: Exception) { }
    }

    /**
     * Fills [target] with the preview of [project]. [onLoaded] runs on the main thread:
     * true when a picture is now showing (so the caller can hide its placeholder icon).
     */
    fun bind(ctx: Context, project: CanvasProject, target: ImageView, sizePx: Int, onLoaded: (Boolean) -> Unit) {
        val path = project.devicePath
        if (path == null) { target.tag = null; target.setImageDrawable(null); onLoaded(false); return }
        val file = File(path)
        night = (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        val key = keyOf(file, sizePx)
        target.tag = key
        mem.get(key)?.let {
            target.setImageBitmap(it)
            target.alpha = 1f
            onLoaded(true)
            return
        }
        target.setImageDrawable(null)
        onLoaded(false)
        val type = FileKinds.typeOf(file.extension) ?: return
        if (type == SourceType.MODEL) return
        val app = ctx.applicationContext

        fun deliver(bmp: Bitmap?) {
            if (bmp == null) return
            mem.put(key, bmp)
            if (target.tag == key) {
                target.setImageBitmap(bmp)
                target.alpha = 0f
                target.animate().alpha(1f).setDuration(180).start()
                onLoaded(true)
            }
        }

        io.execute {
            if (target.tag != key) return@execute
            val cached = File(dir(app), "$key.jpg")
            if (cached.exists()) {
                val b = try { android.graphics.BitmapFactory.decodeFile(cached.absolutePath) } catch (_: Throwable) { null }
                if (b != null) { cached.setLastModified(System.currentTimeMillis()); main.post { deliver(b) }; return@execute }
            }
            fun finish(b: Bitmap?) {
                if (b == null) return
                try {
                    cached.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 86, it) }
                } catch (_: Exception) { }
                main.post { deliver(b) }
            }
            when (type) {
                SourceType.HTML, SourceType.SVG, SourceType.ZIP -> {
                    if (type == SourceType.ZIP && file.length() > 30L * 1024 * 1024) return@execute
                    main.post {
                        val w = web ?: return@post
                        w.enqueue(file, sizePx, { target.tag != key }) { bmp ->
                            if (bmp != null) io.execute { finish(bmp) }
                        }
                    }
                }
                SourceType.FONT -> finish(drawFont(file, sizePx))
                SourceType.GEOJSON -> finish(drawGeo(file, sizePx))
                else -> finish(drawText(file, type, sizePx))
            }
        }
    }

    // ------------------------------------------------------------------ drawing

    private fun card(size: Int, bg: Int): Pair<Bitmap, Canvas> {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(bg)
        return bmp to c
    }

    private fun readHead(file: File, max: Int): String {
        return try {
            file.inputStream().use { ins ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(4096)
                var total = 0
                while (total < max) {
                    val n = ins.read(buf, 0, minOf(buf.size, max - total))
                    if (n <= 0) break
                    out.write(buf, 0, n); total += n
                }
                out.toString("UTF-8")
            }
        } catch (_: Exception) { "" }
    }

    private fun drawText(file: File, type: SourceType, size: Int): Bitmap? {
        var text = readHead(file, 6000)
        if (text.isBlank()) return null
        val (bmp, c) = card(size, cBg())
        val pad = size * 0.09f
        val markdown = type == SourceType.MARKDOWN
        val lines = text.replace("\r", "").split("\n")
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var y = pad
        val mono = !markdown
        for (raw in lines) {
            if (y > size - pad) break
            var line = raw
            var heading = false
            if (markdown) {
                if (line.isBlank()) { y += size * 0.03f; continue }
                if (line.trimStart().startsWith("#")) { heading = true; line = line.trimStart().trimStart('#').trim() }
                line = line.replace(Regex("[*_`>]|!?\\[|\\]\\([^)]*\\)"), "").trim()
                if (line.startsWith("<")) continue
            } else {
                line = line.replace("\t", "  ")
                if (line.isBlank() && y < pad + 1) continue
            }
            p.typeface = if (heading) Typeface.create("sans-serif", Typeface.BOLD) else if (mono) Typeface.MONOSPACE else Typeface.SANS_SERIF
            p.textSize = if (heading) size * 0.085f else size * 0.062f
            p.color = if (heading) cStrong() else cSoft()
            y += p.textSize * 1.15f
            val clipped = if (p.measureText(line) > size - 2 * pad)
                line.substring(0, p.breakText(line, true, size - 2 * pad, null)) else line
            c.drawText(clipped, pad, y, p)
            y += p.textSize * 0.25f
        }
        // gentle fade at the bottom so it reads as "more below"
        val fade = Paint().apply {
            shader = android.graphics.LinearGradient(0f, size * 0.8f, 0f, size.toFloat(),
                Color.TRANSPARENT, cBg(), android.graphics.Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, size * 0.8f, size.toFloat(), size.toFloat(), fade)
        return bmp
    }

    private fun drawFont(file: File, size: Int): Bitmap? {
        val tf = try { Typeface.createFromFile(file) } catch (_: Throwable) { return null }
        val (bmp, c) = card(size, cBg())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = tf
        p.color = cStrong()
        p.textSize = size * 0.5f
        p.textAlign = Paint.Align.CENTER
        c.drawText("Aa", size / 2f, size * 0.55f, p)
        p.textSize = size * 0.095f
        p.color = cSoft()
        c.drawText("Abc 123", size / 2f, size * 0.78f, p)
        return bmp
    }

    private fun drawGeo(file: File, size: Int): Bitmap? {
        if (file.length() > 3L * 1024 * 1024) return null
        val root = try { JSONObject(file.readText()) } catch (_: Exception) { return null }
        val shapes = ArrayList<Pair<Int, List<DoubleArray>>>() // 0 point, 1 line, 2 ring
        var budget = 30000
        fun ring(a: JSONArray): List<DoubleArray> {
            val out = ArrayList<DoubleArray>()
            for (i in 0 until a.length()) {
                if (budget-- <= 0) break
                val pt = a.optJSONArray(i) ?: continue
                out.add(doubleArrayOf(pt.optDouble(0), pt.optDouble(1)))
            }
            return out
        }
        fun geom(g: JSONObject?) {
            if (g == null) return
            val coords = g.optJSONArray("coordinates")
            when (g.optString("type")) {
                "Point" -> coords?.let { shapes.add(0 to listOf(doubleArrayOf(it.optDouble(0), it.optDouble(1)))) }
                "MultiPoint" -> coords?.let { for (i in 0 until it.length()) shapes.add(0 to ring(JSONArray().put(it.optJSONArray(i)))) }
                "LineString" -> coords?.let { shapes.add(1 to ring(it)) }
                "MultiLineString" -> coords?.let { for (i in 0 until it.length()) it.optJSONArray(i)?.let { l -> shapes.add(1 to ring(l)) } }
                "Polygon" -> coords?.let { for (i in 0 until it.length()) it.optJSONArray(i)?.let { r -> shapes.add(2 to ring(r)) } }
                "MultiPolygon" -> coords?.let { for (i in 0 until it.length()) it.optJSONArray(i)?.let { poly ->
                    for (j in 0 until poly.length()) poly.optJSONArray(j)?.let { r -> shapes.add(2 to ring(r)) } } }
                "GeometryCollection" -> g.optJSONArray("geometries")?.let { for (i in 0 until it.length()) geom(it.optJSONObject(i)) }
            }
        }
        fun walk(o: JSONObject) {
            when (o.optString("type")) {
                "FeatureCollection" -> o.optJSONArray("features")?.let { for (i in 0 until it.length()) it.optJSONObject(i)?.let(::walk) }
                "Feature" -> geom(o.optJSONObject("geometry"))
                else -> geom(o)
            }
        }
        walk(root)
        if (shapes.isEmpty()) return null
        var minX = Double.MAX_VALUE; var maxX = -Double.MAX_VALUE
        var minY = Double.MAX_VALUE; var maxY = -Double.MAX_VALUE
        for ((_, pts) in shapes) for (pt in pts) {
            if (pt[0].isNaN() || pt[1].isNaN()) continue
            minX = minOf(minX, pt[0]); maxX = maxOf(maxX, pt[0]); minY = minOf(minY, pt[1]); maxY = maxOf(maxY, pt[1])
        }
        if (minX > maxX) return null
        val midLat = (minY + maxY) / 2
        val kx = Math.cos(Math.toRadians(midLat)).coerceAtLeast(0.2)
        val w = ((maxX - minX) * kx).coerceAtLeast(1e-9)
        val h = (maxY - minY).coerceAtLeast(1e-9)
        val pad = size * 0.12f
        val scale = ((size - 2 * pad) / maxOf(w, h)).toFloat()
        val ox = (size - w.toFloat() * scale) / 2f
        val oy = (size - h.toFloat() * scale) / 2f
        fun px(x: Double) = ox + ((x - minX) * kx).toFloat() * scale
        fun py(y: Double) = oy + ((maxY - y)).toFloat() * scale

        val (bmp, c) = card(size, Color.parseColor(if (night) "#1B2430" else "#E6EEF8"))
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#550381FE"); style = Paint.Style.FILL }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0381FE"); style = Paint.Style.STROKE; strokeWidth = size * 0.012f + 1f
            strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E5484D") }
        for ((kind, pts) in shapes) {
            if (kind == 0) { pts.forEach { c.drawCircle(px(it[0]), py(it[1]), size * 0.022f + 1f, dot) }; continue }
            val path = Path()
            pts.forEachIndexed { i, pt -> if (i == 0) path.moveTo(px(pt[0]), py(pt[1])) else path.lineTo(px(pt[0]), py(pt[1])) }
            if (kind == 2) { path.close(); c.drawPath(path, fill) }
            c.drawPath(path, stroke)
        }
        return bmp
    }
}
