package com.canvaplayer.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import androidx.annotation.RequiresApi
import com.canvaplayer.app.R

/**
 * A "Liquid Glass" panel: a rounded, translucent surface with a soft light
 * sheen and a bright hairline edge. On Android 12+ it can also show a REAL
 * frosted blur of whatever sits behind it — set `app:glassBlurTarget` to the
 * id of the sibling view (the page background + list) it should blur. On
 * older phones, or if blur is unavailable, it falls back to the same
 * translucent tint, so it always stays readable.
 *
 * The blurred copy is redrawn when the panel is drawn; call [refresh] when
 * the content behind changes (the home screen does this while scrolling).
 */
class GlassLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density
    private var radius = 24f * density
    private var tintColor = context.getColor(R.color.glass_tint)
    private var blurTargetId = View.NO_ID
    private var blurPx = 22f * density
    private var blurFailed = false

    private val rect = RectF()
    private val clip = Path()
    private val edge = Path()
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = density
    }
    private var node: RenderNode? = null
    private val loc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        setWillNotDraw(false)
        val a = context.obtainStyledAttributes(attrs, R.styleable.GlassLayout, defStyleAttr, 0)
        try {
            radius = a.getDimension(R.styleable.GlassLayout_glassRadius, radius)
            tintColor = a.getColor(R.styleable.GlassLayout_glassTint, tintColor)
            blurTargetId = a.getResourceId(R.styleable.GlassLayout_glassBlurTarget, View.NO_ID)
            blurPx = a.getDimension(R.styleable.GlassLayout_glassBlurRadius, blurPx)
        } finally {
            a.recycle()
        }
        tintPaint.color = tintColor
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        val r = minOf(radius, w / 2f, h / 2f)
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        val inset = strokePaint.strokeWidth / 2f
        edge.reset()
        edge.addRoundRect(inset, inset, w - inset, h - inset, r - inset, r - inset, Path.Direction.CW)

        val sheen = context.getColor(R.color.glass_sheen)
        sheenPaint.shader = LinearGradient(0f, 0f, 0f, h * 0.7f, sheen, 0x00FFFFFF, Shader.TileMode.CLAMP)
        val stroke = context.getColor(R.color.glass_stroke)
        val faint = (stroke and 0x00FFFFFF) or (((stroke ushr 24) / 4) shl 24)
        strokePaint.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), stroke, faint, Shader.TileMode.CLAMP)
    }

    /** Redraw the frosted backdrop (cheap); call when the content behind it moved. */
    fun refresh() {
        if (blurTargetId != View.NO_ID && !blurFailed) invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        canvas.save()
        canvas.clipPath(clip)
        if (Build.VERSION.SDK_INT >= 31 && blurTargetId != View.NO_ID && !blurFailed &&
            canvas.isHardwareAccelerated
        ) {
            try {
                drawBackdrop(canvas)
            } catch (e: Throwable) {
                blurFailed = true
            }
        }
        canvas.drawPaint(tintPaint)
        canvas.drawRect(rect, sheenPaint)
        canvas.restore()
        canvas.drawPath(edge, strokePaint)
    }

    @RequiresApi(31)
    private fun drawBackdrop(canvas: Canvas) {
        val target = rootView.findViewById<View>(blurTargetId) ?: return
        val n = node ?: RenderNode("glass").also {
            it.setRenderEffect(RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP))
            node = it
        }
        n.setPosition(0, 0, width, height)
        getLocationInWindow(loc)
        target.getLocationInWindow(targetLoc)
        val rec = n.beginRecording()
        try {
            rec.translate((targetLoc[0] - loc[0]).toFloat(), (targetLoc[1] - loc[1]).toFloat())
            target.draw(rec)
        } finally {
            n.endRecording()
        }
        canvas.drawRenderNode(n)
    }
}
