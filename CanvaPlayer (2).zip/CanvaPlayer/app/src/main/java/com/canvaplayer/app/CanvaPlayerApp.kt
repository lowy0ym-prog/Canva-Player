package com.canvaplayer.app

import android.app.Application
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.ThemeManager

class CanvaPlayerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        ThemeManager.applySavedMode(this)
        removeOldSamplesOnce()
    }

    /**
     * Older versions pre-loaded sample canvases into the library. The library is
     * now a gallery of the user's own files, so those samples are removed once.
     */
    private fun removeOldSamplesOnce() {
        val prefs = getSharedPreferences("canva_player_prefs", MODE_PRIVATE)
        if (prefs.getBoolean("samples_removed", false)) return
        Thread {
            try {
                val repo = CanvasRepository.getInstance(this)
                repo.getAll().filter { it.sourceType == CanvasProject.SourceType.BUILT_IN }
                    .forEach { repo.delete(it) }
                prefs.edit().putBoolean("samples_removed", true).apply()
            } catch (_: Exception) { }
        }.start()
    }
}
