package com.canvaplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.thumbs.Thumbnails
import com.canvaplayer.app.ui.PressFeedback

/** One "album" of the gallery: a folder that holds at least one supported file. [cover] gives its picture. */
data class FolderEntry(val key: String, val name: String, val count: Int, val cover: CanvasProject? = null)

class FolderAdapter(
    private val onOpen: (FolderEntry) -> Unit
) : RecyclerView.Adapter<FolderAdapter.Holder>() {

    private var items: List<FolderEntry> = emptyList()

    fun submit(newItems: List<FolderEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])

    override fun getItemCount() = items.size

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val name: TextView = view.findViewById(R.id.txtFolderName)
        private val count: TextView = view.findViewById(R.id.txtFolderCount)
        private val thumb: ImageView = view.findViewById(R.id.imgThumb)
        private val icon: ImageView = view.findViewById(R.id.imgTypeIcon)
        private val box: View = view.findViewById(R.id.thumbBox)

        init { box.clipToOutline = true }

        fun bind(folder: FolderEntry) {
            val ctx = itemView.context
            name.text = folder.name
            count.text = if (folder.count == 1) ctx.getString(R.string.files_count_one)
            else ctx.getString(R.string.files_count_many, folder.count)
            icon.visibility = View.VISIBLE
            val cover = folder.cover
            if (cover != null) {
                Thumbnails.bind(ctx, cover, thumb, THUMB_PX) { loaded ->
                    icon.visibility = if (loaded) View.GONE else View.VISIBLE
                }
            } else {
                thumb.tag = null
                thumb.setImageDrawable(null)
            }
            PressFeedback.apply(itemView, 0.97f)
            itemView.setOnClickListener { onOpen(folder) }
        }
    }

    companion object { const val THUMB_PX = 360 }
}
