package com.canvaplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** One "album" of the gallery: a folder that holds at least one supported file. */
data class FolderEntry(val key: String, val name: String, val count: Int)

class FolderAdapter(
    private val onOpen: (FolderEntry) -> Unit
) : RecyclerView.Adapter<FolderAdapter.Holder>() {

    private var items: List<FolderEntry> = emptyList()

    fun submit(newItems: List<FolderEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])

    override fun getItemCount() = items.size

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val name: TextView = view.findViewById(R.id.txtFolderName)
        private val count: TextView = view.findViewById(R.id.txtFolderCount)

        fun bind(folder: FolderEntry) {
            val ctx = itemView.context
            name.text = folder.name
            count.text = if (folder.count == 1) ctx.getString(R.string.folder_count_one)
            else ctx.getString(R.string.folder_count_many, folder.count)
            itemView.setOnClickListener { onOpen(folder) }
        }
    }
}
