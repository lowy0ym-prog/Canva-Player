package com.canvaplayer.app.viewer

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.Locale

/**
 * AI-made pages very often pull a popular library (three.js, ...) from a
 * public CDN. This app has no internet permission, so those requests can
 * never succeed — but the library files themselves are small. For the few
 * libraries bundled inside the app (assets/cdn, assets/viewer3d) the request
 * is answered from the app's own copy instead. Nothing is ever fetched from
 * the network; unknown hosts are simply refused.
 */
object OfflineLibs {

    private val CDN_HOSTS = setOf(
        "cdnjs.cloudflare.com", "cdn.jsdelivr.net", "unpkg.com", "ajax.googleapis.com",
        "threejs.org", "esm.sh", "cdn.skypack.dev"
    )
    private val FONT_HOSTS = setOf("fonts.googleapis.com", "fonts.gstatic.com")

    private val CORS = mapOf("Access-Control-Allow-Origin" to "*")

    /** Returns a response for a bundled library / harmless font request, or null. */
    fun open(context: Context, url: Uri): WebResourceResponse? {
        val host = url.host?.lowercase(Locale.ROOT) ?: return null
        val path = url.path?.lowercase(Locale.ROOT) ?: return null

        if (host in FONT_HOSTS) {
            // Web fonts: answer with an empty file so the page quietly falls
            // back to the phone's own fonts instead of waiting on a timeout.
            val mime = if (host == "fonts.googleapis.com") "text/css" else "font/woff2"
            return WebResourceResponse(mime, "UTF-8", 200, "OK", CORS, ByteArrayInputStream(ByteArray(0)))
        }
        if (host !in CDN_HOSTS) return null

        val asset: String? = when {
            // Classic (global THREE) builds, as used by r128-era pages.
            path.endsWith("/three.min.js") -> "cdn/three-r128/three.min.js"
            path.contains("/examples/js/") && path.endsWith("/gltfloader.js") -> "cdn/three-r128/GLTFLoader.js"
            path.contains("/examples/js/") && path.endsWith("/orbitcontrols.js") -> "cdn/three-r128/OrbitControls.js"
            // Module builds.
            path.endsWith("/three.module.js") || path.endsWith("/three.module.min.js") ->
                "viewer3d/lib/three.module.min.js"
            path.contains("/examples/jsm/loaders/gltfloader.js") -> "viewer3d/lib/loaders/GLTFLoader.js"
            path.contains("/examples/jsm/controls/orbitcontrols.js") -> "viewer3d/lib/controls/OrbitControls.js"
            path.contains("/examples/jsm/utils/buffergeometryutils.js") -> "viewer3d/lib/utils/BufferGeometryUtils.js"
            else -> null
        }
        if (asset == null) return null
        return try {
            WebResourceResponse("text/javascript", "UTF-8", 200, "OK", CORS, context.assets.open(asset))
        } catch (e: Exception) {
            null
        }
    }
}
