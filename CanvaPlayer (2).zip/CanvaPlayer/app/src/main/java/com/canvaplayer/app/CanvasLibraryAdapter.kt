package com.canvaplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.model.CanvasProject.SourceType
import com.canvaplayer.app.thumbs.Thumbnails
import com.canvaplayer.app.ui.PressFeedback
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.viewer.FileKinds

/** Icon + short tag for each kind of file. */
object TypeUi {
    fun icon(t: SourceType): Int = when (t) {
        SourceType.ZIP -> R.drawable.ic_zip_doc
        SourceType.MARKDOWN -> R.drawable.ic_md_doc
        SourceType.MODEL -> R.drawable.ic_3d_doc
        SourceType.GEOJSON -> R.drawable.ic_map_doc
        SourceType.CSS, SourceType.JS -> R.drawable.ic_code_doc
        SourceType.FONT -> R.drawable.ic_font_doc
        SourceType.DATA -> R.drawable.ic_data_doc
        SourceType.TEXT -> R.drawable.ic_text_doc
        SourceType.SVG -> R.drawable.ic_image_doc
        else -> R.drawable.ic_html_doc
    }

    fun badge(project: CanvasProject): String =
        project.devicePath?.substringAfterLast('.', "")?.uppercase()?.take(8)?.ifBlank { null }
            ?: FileKinds.label(project.sourceType)
}

/** Gallery grid (square previews) or One UI grouped list. */
class CanvasLibraryAdapter(
    private val onOpen: (CanvasProject) -> Unit,
    private val onToggleFavorite: (CanvasProject) -> Unit,
    private val onMoreOptions: (CanvasProject) -> Unit
) : RecyclerView.Adapter<CanvasLibraryAdapter.CanvasViewHolder>() {

    enum class ViewMode { LIST, GRID }

    private val items = mutableListOf<CanvasProject>()

    var viewMode: ViewMode = ViewMode.GRID
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    fun submitList(newItems: List<CanvasProject>) {
        val old = items.toList()
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = newItems.size
            override fun areItemsTheSame(o: Int, n: Int) = old[o].id == newItems[n].id
            override fun areContentsTheSame(o: Int, n: Int) = old[o] == newItems[n]
        })
        items.clear()
        items.addAll(newItems)
        diff.dispatchUpdatesTo(this)
        // list rows round their corners by position, so neighbours must refresh too
        if (viewMode == ViewMode.LIST && items.isNotEmpty()) notifyItemRangeChanged(0, items.size, "pos")
    }

    override fun getItemViewType(position: Int): Int = viewMode.ordinal

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CanvasViewHolder {
        val list = viewType == ViewMode.LIST.ordinal
        val layout = if (list) R.layout.item_file_list else R.layout.item_file_grid
        return CanvasViewHolder(LayoutInflater.from(parent.context).inflate(layout, parent, false), list)
    }

    override fun onBindViewHolder(holder: CanvasViewHolder, position: Int) =
        holder.bind(items[position], position, items.size)

    override fun onBindViewHolder(holder: CanvasViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == "pos" }) holder.applyPosition(position, items.size)
        else onBindViewHolder(holder, position)
    }

    override fun getItemCount(): Int = items.size

    inner class CanvasViewHolder(view: View, private val list: Boolean) : RecyclerView.ViewHolder(view) {
        private val card: View = view.findViewById(R.id.card)
        private val txtName: TextView = view.findViewById(R.id.txtName)
        private val txtType: TextView = view.findViewById(R.id.txtType)
        private val imgThumb: ImageView = view.findViewById(R.id.imgThumb)
        private val imgTypeIcon: ImageView = view.findViewById(R.id.imgTypeIcon)
        private val thumbBox: View = view.findViewById(R.id.thumbBox)
        private val btnFavorite: ImageButton = view.findViewById(R.id.btnFavorite)
        private val btnMore: ImageButton? = view.findViewById(R.id.btnMore)
        private val txtBadge: TextView? = view.findViewById(R.id.txtBadge)
        private val divider: View? = view.findViewById(R.id.divider)

        init { thumbBox.clipToOutline = true }

        fun applyPosition(position: Int, count: Int) {
            if (!list) return
            val first = position == 0
            val last = position == count - 1
            card.setBackgroundResource(
                when {
                    first && last -> R.drawable.bg_block_single
                    first -> R.drawable.bg_block_top
                    last -> R.drawable.bg_block_bottom
                    else -> R.drawable.bg_block_mid
                }
            )
            divider?.visibility = if (last) View.GONE else View.VISIBLE
        }

        fun bind(project: CanvasProject, position: Int, count: Int) {
            val ctx = itemView.context
            txtName.text = project.name
            val kind = FileKinds.label(project.sourceType)
            val size = FileUtils.humanReadableSize(project.sizeBytes)
            txtType.text = if (list) {
                val where = if (project.isDeviceFile) java.io.File(project.folderName).name else ctx.getString(R.string.saved_in_app)
                "$kind · $size · $where"
            } else "$kind · $size"

            imgTypeIcon.setImageResource(TypeUi.icon(project.sourceType))
            imgTypeIcon.visibility = View.VISIBLE
            Thumbnails.bind(ctx, project, imgThumb, FolderAdapter.THUMB_PX) { loaded ->
                imgTypeIcon.visibility = if (loaded) View.GONE else View.VISIBLE
            }
            txtBadge?.text = TypeUi.badge(project)

            btnFavorite.setImageResource(
                if (project.favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
            )
            if (!list) {
                btnFavorite.setColorFilter(
                    if (project.favorite) ctx.getColor(R.color.cp_heart) else android.graphics.Color.WHITE
                )
            }
            applyPosition(position, count)

            PressFeedback.apply(card, if (list) 0.985f else 0.965f)
            card.setOnClickListener { onOpen(project) }
            card.setOnLongClickListener {
                it.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                onMoreOptions(project); true
            }
            btnFavorite.setOnClickListener { onToggleFavorite(project) }
            btnMore?.setOnClickListener { onMoreOptions(project) }
        }
    }
}
