package com.canvaplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils

class CanvasLibraryAdapter(
    private val onOpen: (CanvasProject) -> Unit,
    private val onToggleFavorite: (CanvasProject) -> Unit,
    private val onMoreOptions: (CanvasProject) -> Unit
) : RecyclerView.Adapter<CanvasLibraryAdapter.CanvasViewHolder>() {

    /** GRID = compact cards (two columns); LIST = detailed full-width rows. */
    enum class ViewMode { LIST, GRID }

    private val items = mutableListOf<CanvasProject>()

    var viewMode: ViewMode = ViewMode.GRID
        set(value) {
            if (field != value) {
                field = value
                // Different item layout per mode: rebuild all holders.
                notifyDataSetChanged()
            }
        }

    fun submitList(newItems: List<CanvasProject>) {
        val old = items.toList()
        val diffResult = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = newItems.size
            override fun areItemsTheSame(oldPos: Int, newPos: Int) =
                old[oldPos].id == newItems[newPos].id
            override fun areContentsTheSame(oldPos: Int, newPos: Int) =
                old[oldPos] == newItems[newPos]
        })
        items.clear()
        items.addAll(newItems)
        diffResult.dispatchUpdatesTo(this)
    }

    override fun getItemViewType(position: Int): Int = viewMode.ordinal

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CanvasViewHolder {
        val layout = if (viewType == ViewMode.LIST.ordinal) R.layout.item_canvas_list
        else R.layout.item_canvas_card
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return CanvasViewHolder(view, viewType == ViewMode.LIST.ordinal)
    }

    override fun onBindViewHolder(holder: CanvasViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class CanvasViewHolder(view: View, private val detailed: Boolean) :
        RecyclerView.ViewHolder(view) {

        private val txtName: TextView = view.findViewById(R.id.txtName)
        private val txtType: TextView = view.findViewById(R.id.txtType)
        private val txtLastOpened: TextView = view.findViewById(R.id.txtLastOpened)
        private val imgTypeIcon: ImageView = view.findViewById(R.id.imgTypeIcon)
        private val btnFavorite: ImageButton = view.findViewById(R.id.btnFavorite)
        private val btnMore: ImageButton = view.findViewById(R.id.btnMore)

        fun bind(project: CanvasProject) {
            val ctx = itemView.context
            txtName.text = project.name
            val isZip = project.sourceType == CanvasProject.SourceType.ZIP
            imgTypeIcon.setImageResource(
                when (project.sourceType) {
                    CanvasProject.SourceType.ZIP -> R.drawable.ic_zip_doc
                    CanvasProject.SourceType.MARKDOWN -> R.drawable.ic_md_doc
                    CanvasProject.SourceType.MODEL -> R.drawable.ic_3d_doc
                    else -> R.drawable.ic_html_doc
                }
            )
            val kind = when (project.sourceType) {
                CanvasProject.SourceType.ZIP -> "ZIP project"
                CanvasProject.SourceType.MARKDOWN -> "Markdown document"
                CanvasProject.SourceType.MODEL -> "3D model"
                else -> ctx.getString(R.string.interactive_canvas)
            }
            txtType.text = kind

            if (detailed) {
                txtType.text = "$kind · ${FileUtils.humanReadableSize(project.sizeBytes)}"
                val opened = if (project.lastOpened > 0L) FileUtils.formatDate(project.lastOpened)
                else ctx.getString(R.string.never_opened)
                txtLastOpened.text = "Added ${FileUtils.formatDate(project.dateAdded)} · $opened"
            } else {
                txtLastOpened.text = if (project.lastOpened > 0L) {
                    ctx.getString(R.string.recently_opened) + " · " + FileUtils.formatDate(project.lastOpened)
                } else {
                    ctx.getString(R.string.never_opened)
                }
            }

            btnFavorite.setImageResource(
                if (project.favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
            )
            itemView.setOnClickListener { onOpen(project) }
            btnFavorite.setOnClickListener { onToggleFavorite(project) }
            btnMore.setOnClickListener { onMoreOptions(project) }
        }
    }
}
