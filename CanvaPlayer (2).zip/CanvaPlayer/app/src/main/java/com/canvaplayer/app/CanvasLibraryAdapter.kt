package com.canvaplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.model.CanvasProject.SourceType
import com.canvaplayer.app.thumbs.Thumbnails
import com.canvaplayer.app.ui.PressFeedback
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.viewer.FileKinds

/** Icon + short tag for each kind of file. */
object TypeUi {
    fun icon(t: SourceType): Int = when (t) {
        SourceType.ZIP -> R.drawable.ic_zip_doc
        SourceType.MARKDOWN -> R.drawable.ic_md_doc
        SourceType.MODEL -> R.drawable.ic_3d_doc
        SourceType.GEOJSON -> R.drawable.ic_map_doc
        SourceType.CSS, SourceType.JS -> R.drawable.ic_code_doc
        SourceType.FONT -> R.drawable.ic_font_doc
        SourceType.DATA -> R.drawable.ic_data_doc
        SourceType.TEXT -> R.drawable.ic_text_doc
        SourceType.SVG -> R.drawable.ic_image_doc
        else -> R.drawable.ic_html_doc
    }

    fun badge(project: CanvasProject): String =
        project.devicePath?.substringAfterLast('.', "")?.uppercase()?.take(8)?.ifBlank { null }
            ?: FileKinds.label(project.sourceType)
}

/** Gallery grid (square previews) or One UI grouped list. */
class CanvasLibraryAdapter(
    private val onOpen: (CanvasProject) -> Unit,
    private val onToggleFavorite: (CanvasProject) -> Unit,
    private val onMoreOptions: (CanvasProject) -> Unit
) : RecyclerView.Adapter<CanvasLibraryAdapter.CanvasViewHolder>() {

    enum class ViewMode { LIST, GRID }

    /** Rows are files, or a String section title (date groups in the picture grid). */
    private val rows = mutableListOf<Any>()
    private val items: List<CanvasProject> get() = rows.filterIsInstance<CanvasProject>()

    /** Gallery-style: edge-to-edge square tiles grouped under date headers. */
    var pictureMode: Boolean = false

    fun isHeader(position: Int) = rows.getOrNull(position) is String

    /** The date group the row at [position] belongs to. */
    fun sectionFor(position: Int): String? {
        var i = position.coerceIn(0, (rows.size - 1).coerceAtLeast(0))
        while (i >= 0) { (rows.getOrNull(i) as? String)?.let { return it }; i-- }
        return null
    }

    /** 0 = names + badges (big tiles), 1 = badges only, 2 = pictures only (tiny tiles). */
    var tileDetail: Int = 0
        set(v) { if (field != v) { field = v; notifyDataSetChanged() } }

    var viewMode: ViewMode = ViewMode.GRID
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    fun submitList(newItems: List<CanvasProject>, section: ((CanvasProject) -> String)? = null) {
        val newRows = ArrayList<Any>()
        if (section == null) newRows.addAll(newItems) else {
            var last: String? = null
            for (p in newItems) {
                val key = section(p)
                if (key != last) { newRows.add(key); last = key }
                newRows.add(p)
            }
        }
        val old = rows.toList()
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = newRows.size
            override fun areItemsTheSame(o: Int, n: Int): Boolean {
                val a = old[o]; val b = newRows[n]
                return if (a is CanvasProject && b is CanvasProject) a.id == b.id else a == b
            }
            override fun areContentsTheSame(o: Int, n: Int) = old[o] == newRows[n]
        })
        rows.clear()
        rows.addAll(newRows)
        diff.dispatchUpdatesTo(this)
        // list rows round their corners by position, so neighbours must refresh too
        if (!pictureMode && viewMode == ViewMode.LIST && rows.isNotEmpty()) notifyItemRangeChanged(0, rows.size, "pos")
    }

    override fun getItemViewType(position: Int): Int = when {
        rows[position] is String -> 3
        pictureMode -> 2
        else -> viewMode.ordinal
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CanvasViewHolder {
        if (viewType == 3) {
            return CanvasViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_section, parent, false), false, 3)
        }
        if (viewType == 2) {
            return CanvasViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_picture, parent, false), false, 2)
        }
        val list = viewType == ViewMode.LIST.ordinal
        val layout = if (list) R.layout.item_file_list else R.layout.item_file_grid
        return CanvasViewHolder(LayoutInflater.from(parent.context).inflate(layout, parent, false), list, if (list) 0 else 1)
    }

    override fun onBindViewHolder(holder: CanvasViewHolder, position: Int) {
        val row = rows[position]
        if (row is String) holder.bindHeader(row) else holder.bind(row as CanvasProject, position, rows.size)
    }

    override fun onBindViewHolder(holder: CanvasViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == "pos" }) holder.applyPosition(position, rows.size)
        else onBindViewHolder(holder, position)
    }

    override fun getItemCount(): Int = rows.size

    inner class CanvasViewHolder(view: View, private val list: Boolean, private val kind: Int) : RecyclerView.ViewHolder(view) {
        private val card: View? = view.findViewById(R.id.card)
        private val txtName: TextView? = view.findViewById(R.id.txtName)
        private val txtType: TextView? = view.findViewById(R.id.txtType)
        private val imgThumb: ImageView? = view.findViewById(R.id.imgThumb)
        private val imgTypeIcon: ImageView? = view.findViewById(R.id.imgTypeIcon)
        private val thumbBox: View? = view.findViewById(R.id.thumbBox)
        private val btnFavorite: View? = view.findViewById(R.id.btnFavorite)
        private val btnMore: ImageButton? = view.findViewById(R.id.btnMore)
        private val txtBadge: TextView? = view.findViewById(R.id.txtBadge)
        private val divider: View? = view.findViewById(R.id.divider)
        private val scrim: View? = view.findViewById(R.id.scrim)

        init { thumbBox?.clipToOutline = true }

        fun bindHeader(title: String) { (itemView as TextView).text = title }

        fun applyPosition(position: Int, count: Int) {
            if (!list) return
            val first = position == 0
            val last = position == count - 1
            card?.setBackgroundResource(
                when {
                    first && last -> R.drawable.bg_block_single
                    first -> R.drawable.bg_block_top
                    last -> R.drawable.bg_block_bottom
                    else -> R.drawable.bg_block_mid
                }
            )
            divider?.visibility = if (last) View.GONE else View.VISIBLE
        }

        fun bind(project: CanvasProject, position: Int, count: Int) {
            val ctx = itemView.context
            val card = card!!
            txtName?.text = project.name
            val kindLabel = FileKinds.label(project.sourceType)
            val size = FileUtils.humanReadableSize(project.sizeBytes)
            txtType?.text = if (list) {
                val where = if (project.isDeviceFile) java.io.File(project.folderName).name else ctx.getString(R.string.saved_in_app)
                "$kindLabel · $size · $where"
            } else "$kindLabel · $size"

            imgTypeIcon!!.setImageResource(TypeUi.icon(project.sourceType))
            imgTypeIcon.visibility = View.VISIBLE
            Thumbnails.bind(ctx, project, imgThumb!!, FolderAdapter.THUMB_PX) { loaded ->
                imgTypeIcon.visibility = if (loaded) View.GONE else View.VISIBLE
            }
            txtBadge?.text = TypeUi.badge(project)

            if (kind == 2) {
                txtName?.visibility = if (tileDetail == 0) View.VISIBLE else View.GONE
                scrim?.visibility = if (tileDetail == 0) View.VISIBLE else View.GONE
                txtBadge?.visibility = if (tileDetail <= 1) View.VISIBLE else View.GONE
                val s = if (tileDetail == 2) 0.6f else 1f
                imgTypeIcon?.scaleX = s
                imgTypeIcon?.scaleY = s
                btnFavorite!!.visibility = if (project.favorite && tileDetail <= 1) View.VISIBLE else View.GONE
            } else {
                val fav = btnFavorite as ImageButton
                fav.setImageResource(if (project.favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border)
                if (!list) fav.setColorFilter(if (project.favorite) ctx.getColor(R.color.cp_heart) else android.graphics.Color.WHITE)
                fav.setOnClickListener { onToggleFavorite(project) }
            }
            applyPosition(position, count)

            PressFeedback.apply(card, if (list) 0.985f else if (kind == 2) 0.96f else 0.965f)
            card.setOnClickListener { onOpen(project) }
            card.setOnLongClickListener {
                it.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                onMoreOptions(project); true
            }
            btnMore?.setOnClickListener { onMoreOptions(project) }
        }
    }
}
