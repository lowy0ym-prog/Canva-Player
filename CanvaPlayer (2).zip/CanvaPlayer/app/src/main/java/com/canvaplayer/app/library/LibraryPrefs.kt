package com.canvaplayer.app.library

import android.content.Context

/**
 * Tiny per-file memory for the gallery-style library: favorites, "last
 * opened" times and files the user chose to hide. Keyed by the file's path,
 * so nothing about the files themselves is ever copied or stored.
 */
class LibraryPrefs(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("library_state", Context.MODE_PRIVATE)

    fun isFavorite(path: String) = prefs.getStringSet(KEY_FAV, emptySet())!!.contains(path)

    fun setFavorite(path: String, value: Boolean) {
        val set = prefs.getStringSet(KEY_FAV, emptySet())!!.toMutableSet()
        if (value) set.add(path) else set.remove(path)
        prefs.edit().putStringSet(KEY_FAV, set).apply()
    }

    fun lastOpened(path: String): Long = prefs.getLong("lo_$path", 0L)

    fun markOpened(path: String) {
        prefs.edit().putLong("lo_$path", System.currentTimeMillis()).apply()
    }

    fun hidden(): Set<String> = prefs.getStringSet(KEY_HIDDEN, emptySet())!!.toSet()

    fun hide(path: String) {
        val set = prefs.getStringSet(KEY_HIDDEN, emptySet())!!.toMutableSet()
        set.add(path)
        prefs.edit().putStringSet(KEY_HIDDEN, set).apply()
    }

    fun unhideAll() {
        prefs.edit().remove(KEY_HIDDEN).apply()
    }

    /** Cached answer to "does this ZIP contain a web page?" (keyed by size + modified time). */
    fun zipIsCanvas(path: String, size: Long, modified: Long): Boolean? {
        val v = prefs.getString("zip_$path", null) ?: return null
        val parts = v.split(":")
        if (parts.size != 3 || parts[0] != size.toString() || parts[1] != modified.toString()) return null
        return parts[2] == "1"
    }

    fun rememberZip(path: String, size: Long, modified: Long, isCanvas: Boolean) {
        prefs.edit().putString("zip_$path", "$size:$modified:${if (isCanvas) 1 else 0}").apply()
    }

    private companion object {
        const val KEY_FAV = "favorites"
        const val KEY_HIDDEN = "hidden"
    }
}
