package com.canvaplayer.app.viewer

/**
 * Small compatibility fixes applied to HTML pages as they are served (the
 * file on disk is never changed). AI-made pages were usually previewed
 * somewhere that already did these two things for them:
 *
 *  1. No `<meta name="viewport">`: a phone browser then lays the page out as
 *     if the screen were ~980px wide ("desktop mode", tiny text). A standard
 *     mobile viewport is added only when the page has none.
 *  2. A CSS rule such as `#msg { display:flex }` silently overrides the HTML
 *     `hidden` attribute, so "Loading…" banners never go away. `[hidden]`
 *     is made to win, as the HTML spec intends.
 */
object HtmlPatcher {

    private val VIEWPORT = Regex("<meta[^>]+name\\s*=\\s*[\"']?viewport", RegexOption.IGNORE_CASE)
    private val HEAD = Regex("<head(\\s[^>]*)?>", RegexOption.IGNORE_CASE)
    private val HTML = Regex("<html(\\s[^>]*)?>", RegexOption.IGNORE_CASE)
    private val DOCTYPE = Regex("^\\s*<!doctype[^>]*>", RegexOption.IGNORE_CASE)

    fun patch(html: String): String {
        val inject = (if (VIEWPORT.containsMatchIn(html)) "" else
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">") +
            "<style>[hidden]{display:none!important}</style>"

        val anchor = HEAD.find(html) ?: HTML.find(html)
        if (anchor != null) {
            val at = anchor.range.last + 1
            return html.substring(0, at) + inject + html.substring(at)
        }
        val doctype = DOCTYPE.find(html)
        if (doctype != null) {
            val at = doctype.range.last + 1
            return html.substring(0, at) + inject + html.substring(at)
        }
        return inject + html
    }
}
