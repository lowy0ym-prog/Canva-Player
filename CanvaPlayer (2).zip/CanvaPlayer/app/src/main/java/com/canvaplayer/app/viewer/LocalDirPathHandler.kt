package com.canvaplayer.app.viewer

import android.webkit.MimeTypeMap
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.util.Locale

/**
 * Serves one local folder (read-only) to the viewer WebView, so a page can
 * load its sibling CSS / JS / images / other HTML pages with ordinary
 * relative links — exactly like opening the folder from a web server, but
 * with no network involved. Anything that resolves outside [root] (".."
 * tricks, symlinks) is refused.
 *
 * Unlike the stock InternalStoragePathHandler this also works for folders
 * on shared storage (Downloads, Documents, ...), not just app-private ones.
 */
class LocalDirPathHandler(root: File) : WebViewAssetLoader.PathHandler {

    private val rootCanonical: File = root.canonicalFile

    override fun handle(path: String): WebResourceResponse? {
        return try {
            val rel = path.trimStart('/')
            var target = File(rootCanonical, rel).canonicalFile
            val inside = target.path == rootCanonical.path ||
                target.path.startsWith(rootCanonical.path + File.separator)
            if (!inside) return notFound()
            if (target.isDirectory) target = File(target, "index.html")
            if (!target.isFile) return notFound()
            val mime = mimeFor(target)
            val encoding = if (mime.startsWith("text/") || mime == "application/json" ||
                mime == "image/svg+xml" || mime == "text/javascript"
            ) "UTF-8" else null
            if (mime == "text/html" && target.length() < MAX_PATCHED_HTML) {
                val patched = HtmlPatcher.patch(target.readText(Charsets.UTF_8))
                return WebResourceResponse(mime, "UTF-8", ByteArrayInputStream(patched.toByteArray(Charsets.UTF_8)))
            }
            WebResourceResponse(mime, encoding, FileInputStream(target))
        } catch (e: Exception) {
            notFound()
        }
    }

    private fun notFound() = WebResourceResponse(
        "text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )

    companion object {
        private const val MAX_PATCHED_HTML = 30L * 1024 * 1024

        fun mimeFor(file: File): String {
            val ext = file.extension.lowercase(Locale.ROOT)
            return when (ext) {
                "html", "htm" -> "text/html"
                "js", "mjs", "cjs" -> "text/javascript"
                "css" -> "text/css"
                "json", "geojson", "map" -> "application/json"
                "svg" -> "image/svg+xml"
                "wasm" -> "application/wasm"
                "glb" -> "model/gltf-binary"
                "gltf" -> "model/gltf+json"
                "woff2" -> "font/woff2"
                "woff" -> "font/woff"
                "ttf" -> "font/ttf"
                "otf" -> "font/otf"
                "txt", "md" -> "text/plain"
                else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                    ?: "application/octet-stream"
            }
        }
    }
}
