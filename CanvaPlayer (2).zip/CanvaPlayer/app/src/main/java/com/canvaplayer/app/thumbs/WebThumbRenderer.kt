package com.canvaplayer.app.thumbs

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader
import com.canvaplayer.app.viewer.LocalDirPathHandler
import com.canvaplayer.app.viewer.OfflineLibs
import com.canvaplayer.app.viewer.ViewSource
import java.io.ByteArrayInputStream
import java.io.File
import java.util.ArrayDeque

/**
 * Takes a picture of a page with one hidden WebView, one page at a time. The page is loaded
 * exactly like in the viewer (local files only, every network address refused).
 */
class WebThumbRenderer(private val activity: Activity, private val host: FrameLayout) {

    private class Job(val file: File, val size: Int, val stale: () -> Boolean, val done: (Bitmap?) -> Unit)

    private val ui = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<Job>()
    private var busy = false
    private var destroyed = false
    private var web: WebView? = null
    private var loader: WebViewAssetLoader? = null
    private var current: Job? = null
    private var timeout: Runnable? = null

    private val density = activity.resources.displayMetrics.density
    private val viewW = (360 * density).toInt()
    private val viewH = (450 * density).toInt()

    fun enqueue(file: File, size: Int, stale: () -> Boolean, done: (Bitmap?) -> Unit) {
        if (destroyed) return
        queue.addFirst(Job(file, size, stale, done)) // newest first: what's on screen now wins
        pump()
    }

    fun destroy() {
        destroyed = true
        queue.clear()
        timeout?.let { ui.removeCallbacks(it) }
        web?.let { w ->
            host.removeView(w)
            w.stopLoading()
            w.destroy()
        }
        web = null
    }

    private fun pump() {
        if (busy || destroyed) return
        var job = queue.pollFirst()
        while (job != null && job.stale()) job = queue.pollFirst()
        if (job == null) return
        busy = true
        current = job
        val j = job
        Thread {
            val prepared = try { ViewSource.prepare(activity.applicationContext, j.file) } catch (_: Exception) { null }
            ui.post {
                if (destroyed) return@post
                if (prepared == null || j.stale()) { finish(null); return@post }
                load(j, prepared.rootDir, prepared.entry)
            }
        }.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWeb(): WebView {
        web?.let { return it }
        val w = WebView(activity)
        w.setBackgroundColor(Color.WHITE)
        w.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            loadWithOverviewMode = true
            useWideViewPort = true
            javaScriptCanOpenWindowsAutomatically = false
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean { result?.confirm(); return true }
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean { result?.cancel(); return true }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?) = false
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return null
                if (url.host == ASSET_DOMAIN) return loader?.shouldInterceptRequest(url)
                OfflineLibs.open(activity, url)?.let { return it }
                val scheme = url.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") {
                    return WebResourceResponse("text/plain", "UTF-8", 403, "Blocked (offline)", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true

            override fun onPageFinished(view: WebView?, url: String?) {
                val j = current ?: return
                if (url == null || !url.contains(ASSET_DOMAIN)) return
                // let layout, fonts and a first animation frame settle
                ui.postDelayed({ if (current === j && !destroyed) capture(j) }, 900)
            }
        }
        host.addView(w, FrameLayout.LayoutParams(viewW, viewH))
        web = w
        return w
    }

    private fun load(job: Job, root: File, entry: String) {
        val w = ensureWeb()
        loader = WebViewAssetLoader.Builder()
            .setDomain(ASSET_DOMAIN)
            .addPathHandler("/", LocalDirPathHandler(root))
            .build()
        timeout = Runnable { if (current === job) finish(null) }.also { ui.postDelayed(it, 8000) }
        w.loadUrl("https://$ASSET_DOMAIN/" + android.net.Uri.encode(entry, "/"))
    }

    private fun capture(job: Job) {
        val w = web ?: return finish(null)
        if (job.stale()) return finish(null)
        try {
            val full = Bitmap.createBitmap(viewW, viewH, Bitmap.Config.ARGB_8888)
            w.draw(Canvas(full))
            val side = minOf(viewW, viewH)
            val square = Bitmap.createBitmap(full, 0, 0, side, side)
            val out = Bitmap.createScaledBitmap(square, job.size, job.size, true)
            if (out !== square) square.recycle()
            if (out !== full) full.recycle()
            finish(out)
        } catch (_: Throwable) {
            finish(null)
        }
    }

    private fun finish(bmp: Bitmap?) {
        val j = current
        timeout?.let { ui.removeCallbacks(it) }
        timeout = null
        current = null
        web?.stopLoading()
        web?.loadUrl("about:blank")
        busy = false
        j?.done?.invoke(bmp)
        ui.post { pump() }
    }

    companion object {
        private const val ASSET_DOMAIN = "appassets.androidplatform.net"
    }
}
