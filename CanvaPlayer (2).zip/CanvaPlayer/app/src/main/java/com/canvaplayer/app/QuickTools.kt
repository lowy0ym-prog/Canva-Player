package com.canvaplayer.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog

/**
 * The viewer's "Quick Tools" sheet. Every tool acts on the already-loaded
 * local Canvas only (zoom, find, scroll, print, reload, full screen) — none
 * of them touch the network.
 */
class QuickTools(
    private val activity: AppCompatActivity,
    private val webView: WebView,
    private val onReload: () -> Unit,
    private val onPrint: () -> Unit,
    private val onToggleFullscreen: () -> Unit,
    private val isFullscreen: () -> Boolean
) {
    private var textZoom = 100

    fun show() {
        val dialog = BottomSheetDialog(activity, R.style.Theme_CanvaPlayer_BottomSheet)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dp(12)
            setPadding(pad, dp(16), pad, dp(28))
        }
        root.addView(TextView(activity).apply {
            setText(R.string.quick_tools)
            textSize = 18f
            setPadding(dp(8), 0, 0, dp(8))
        })

        fun row(icon: Int, label: Int, keepOpen: Boolean = false, action: () -> Unit) {
            root.addView(LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                isClickable = true
                isFocusable = true
                val tv = android.util.TypedValue()
                activity.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                setBackgroundResource(tv.resourceId)
                addView(ImageView(activity).apply {
                    setImageResource(icon)
                    layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
                })
                addView(TextView(activity).apply {
                    setText(label)
                    textSize = 16f
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).also { it.marginStart = dp(16) }
                })
                setOnClickListener {
                    if (!keepOpen) dialog.dismiss()
                    action()
                }
            })
        }

        row(R.drawable.ic_refresh, R.string.reload) { onReload() }
        row(R.drawable.ic_print, R.string.print_pdf) { onPrint() }
        row(R.drawable.ic_search, R.string.qt_find) { showFind() }
        row(R.drawable.ic_zoom_in, R.string.qt_zoom_in, keepOpen = true) { setZoom(textZoom + 10) }
        row(R.drawable.ic_zoom_out, R.string.qt_zoom_out, keepOpen = true) { setZoom(textZoom - 10) }
        row(R.drawable.ic_text_reset, R.string.qt_zoom_reset, keepOpen = true) { setZoom(100) }
        row(R.drawable.ic_arrow_up, R.string.qt_top) { webView.scrollTo(0, 0) }
        row(R.drawable.ic_arrow_down, R.string.qt_bottom) { webView.pageDown(true) }
        row(
            R.drawable.ic_fullscreen,
            if (isFullscreen()) R.string.qt_exit_fullscreen else R.string.qt_fullscreen
        ) { onToggleFullscreen() }

        dialog.setContentView(root)
        dialog.show()
    }

    private fun setZoom(value: Int) {
        textZoom = value.coerceIn(50, 250)
        webView.settings.textZoom = textZoom
    }

    private fun showFind() {
        val input = EditText(activity).apply {
            hint = activity.getString(R.string.find_hint)
            setSingleLine()
        }
        val container = LinearLayout(activity).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val dlg = AlertDialog.Builder(activity)
            .setTitle(R.string.qt_find)
            .setView(container)
            .setPositiveButton(R.string.find_next, null)
            .setNeutralButton(R.string.find_prev, null)
            .setNegativeButton(R.string.close, null)
            .setOnDismissListener { webView.clearMatches() }
            .create()
        dlg.show()

        var lastQuery = ""
        fun run(forward: Boolean) {
            val q = input.text.toString()
            if (q.isBlank()) return
            if (q != lastQuery) {
                lastQuery = q
                webView.setFindListener { _, count, done ->
                    if (done && count == 0) {
                        Toast.makeText(activity, R.string.qt_not_found, Toast.LENGTH_SHORT).show()
                    }
                }
                webView.findAllAsync(q)
            } else {
                webView.findNext(forward)
            }
        }
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { run(true) }
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { run(false) }
    }

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()
}
