package com.canvaplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.canvaplayer.app.ui.PressFeedback
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.databinding.ActivityMainBinding
import com.canvaplayer.app.databinding.DialogRenameBinding
import com.canvaplayer.app.databinding.SheetInfoBinding
import com.canvaplayer.app.databinding.SheetProjectMenuBinding
import com.canvaplayer.app.library.DeviceScanner
import com.canvaplayer.app.library.LibraryPrefs
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.model.SortMode
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.thumbs.Thumbnails
import com.canvaplayer.app.thumbs.WebThumbRenderer
import com.canvaplayer.app.viewer.SupportedFiles
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.io.File

/**
 * Gallery-style home screen. Supported files are found automatically on the
 * phone (like a photo gallery finds pictures) and grouped by folder; opening
 * one shows it straight from where it lives — nothing is saved or copied into
 * the app. Fully local, no network.
 */
class MainActivity : AppCompatActivity() {

    private enum class Mode { FOLDERS, ALL, FAVORITES, RECENT }

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: CanvasRepository
    private lateinit var libraryPrefs: LibraryPrefs
    private lateinit var adapter: CanvasLibraryAdapter
    private lateinit var folderAdapter: FolderAdapter

    private var mode = Mode.FOLDERS
    private val uiPrefs by lazy { getSharedPreferences("canva_player_prefs", MODE_PRIVATE) }
    private var currentFolder: FolderEntry? = null
    private var currentSort = SortMode.LAST_OPENED
    private var searchQuery = ""
    private var showingFolders = false
    private var searching = false
    private lateinit var webThumbs: WebThumbRenderer

    private var deviceFiles: List<CanvasProject> = lastScan
    @Volatile private var scanning = false
    private var forceScan = false

    private val pickFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openPickedUri(uri)
    }

    private val legacyPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startScan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupChrome()

        repository = CanvasRepository.getInstance(this)
        libraryPrefs = LibraryPrefs(this)
        mode = runCatching { Mode.valueOf(uiPrefs.getString("home_tab", "FOLDERS")!!) }.getOrDefault(Mode.FOLDERS)
        currentSort = runCatching { SortMode.valueOf(uiPrefs.getString("home_sort", "LAST_OPENED")!!) }
            .getOrDefault(SortMode.LAST_OPENED)

        webThumbs = WebThumbRenderer(this, binding.thumbHost)
        Thumbnails.web = webThumbs

        adapter = CanvasLibraryAdapter(
            onOpen = { openCanvas(it) },
            onToggleFavorite = { toggleFavorite(it) },
            onMoreOptions = { showProjectMenu(it) }
        )
        folderAdapter = FolderAdapter { folder ->
            currentFolder = folder
            refreshList()
            binding.recyclerCanvases.scrollToPosition(0)
        }
        binding.recyclerCanvases.adapter = adapter
        binding.recyclerCanvases.itemAnimator = null
        applyViewMode(loadViewMode())

        setupToolbar()
        setupSearch()
        setupTabs()
        PressFeedback.apply(binding.fabAddCanvas, 0.9f)
        binding.fabAddCanvas.contentDescription = getString(R.string.open_file)
        binding.fabAddCanvas.setOnClickListener { pickFileLauncher.launch(arrayOf("*/*")) }
        binding.btnGrantAccess.setOnClickListener { requestAccess() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    searching -> closeSearch()
                    currentFolder != null -> { currentFolder = null; refreshList() }
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        Thread { SupportedFiles.pruneCache(applicationContext); Thumbnails.prune(applicationContext) }.start()
        refreshList()
    }

    override fun onDestroy() {
        if (Thumbnails.web === webThumbs) Thumbnails.web = null
        webThumbs.destroy()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        startScan()
    }

    // ---------------------------------------------------------------------
    // Finding files
    // ---------------------------------------------------------------------

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            legacyPermissionLauncher.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun startScan() {
        val allowed = DeviceScanner.hasAccess(this)
        binding.permissionCard.visibility = if (allowed) View.GONE else View.VISIBLE
        if (!allowed) {
            deviceFiles = emptyList()
            refreshList()
            return
        }
        if (scanning) return
        // Don't re-walk the disk every time the screen comes back (e.g. from the viewer).
        val now = System.currentTimeMillis()
        if (!forceScan && lastScanAt != 0L && now - lastScanAt < RESCAN_INTERVAL_MS) {
            refreshList()
            return
        }
        forceScan = false
        scanning = true
        binding.scanProgress.visibility = View.VISIBLE
        val appContext = applicationContext
        Thread {
            val result = try { DeviceScanner.scan(appContext) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                scanning = false
                if (isDestroyed) return@runOnUiThread
                binding.scanProgress.visibility = View.GONE
                lastScan = result
                lastScanAt = System.currentTimeMillis()
                deviceFiles = result
                refreshList()
            }
        }.start()
    }

    // ---------------------------------------------------------------------
    // View mode, search, filters, sort
    // ---------------------------------------------------------------------

    private fun loadViewMode(): CanvasLibraryAdapter.ViewMode {
        val saved = uiPrefs.getString("view_mode", "GRID")
        return if (saved == "LIST") CanvasLibraryAdapter.ViewMode.LIST else CanvasLibraryAdapter.ViewMode.GRID
    }

    private fun saveViewMode(mode: CanvasLibraryAdapter.ViewMode) {
        uiPrefs.edit().putString("view_mode", mode.name).apply()
    }

    private fun spanCount(): Int {
        val widthDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        return (widthDp / 170f).toInt().coerceIn(2, 6)
    }

    private fun gridManager() = GridLayoutManager(this, spanCount())

    private fun applyViewMode(viewMode: CanvasLibraryAdapter.ViewMode) {
        adapter.viewMode = viewMode
        if (!showingFolders) {
            binding.recyclerCanvases.layoutManager =
                if (viewMode == CanvasLibraryAdapter.ViewMode.GRID) gridManager() else LinearLayoutManager(this)
        }
        binding.toolbar.menu.findItem(R.id.action_view_toggle)?.setTitle(
            if (viewMode == CanvasLibraryAdapter.ViewMode.GRID) R.string.menu_list_view else R.string.menu_grid_view
        )
    }

    private fun setupToolbar() {
        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_search -> openSearch()
                R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
                R.id.action_view_toggle -> {
                    val next = if (adapter.viewMode == CanvasLibraryAdapter.ViewMode.LIST)
                        CanvasLibraryAdapter.ViewMode.GRID else CanvasLibraryAdapter.ViewMode.LIST
                    saveViewMode(next)
                    applyViewMode(next)
                    fadeList()
                }
                R.id.action_sort -> showSortDialog()
                R.id.action_unhide -> {
                    libraryPrefs.unhideAll()
                    forceScan = true
                    startScan()
                }
            }
            true
        }
        binding.toolbar.setNavigationOnClickListener {
            currentFolder = null
            refreshList()
        }
        applyViewMode(adapter.viewMode)
    }

    private fun openSearch() {
        searching = true
        binding.searchBar.visibility = View.VISIBLE
        binding.toolbar.menu.setGroupVisible(0, false)
        binding.toolbar.navigationIcon = null
        binding.appBar.setExpanded(false, true)
        binding.editSearch.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(binding.editSearch, InputMethodManager.SHOW_IMPLICIT)
        refreshList()
    }

    private fun closeSearch() {
        searching = false
        binding.editSearch.setText("")
        searchQuery = ""
        binding.searchBar.visibility = View.GONE
        binding.toolbar.menu.setGroupVisible(0, true)
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(binding.editSearch.windowToken, 0)
        binding.editSearch.clearFocus()
        refreshList()
    }

    private fun setupSearch() {
        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString().orEmpty()
                refreshList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        binding.editSearch.setOnEditorActionListener { v, _, _ ->
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
            true
        }
        binding.btnSearchBack.setOnClickListener { closeSearch() }
        binding.btnSearchClear.setOnClickListener { binding.editSearch.setText("") }
    }

    private fun tabViews() = listOf(
        binding.tabFolders to Mode.FOLDERS,
        binding.tabAll to Mode.ALL,
        binding.tabFavorites to Mode.FAVORITES,
        binding.tabRecent to Mode.RECENT
    )

    /**
     * One UI text tabs. "Pressed" is a grey pill (drawn by the tab background while the finger is
     * down); "selected" is a bold, underlined, full-contrast label. The two never look alike.
     */
    private fun styleTabs() {
        tabViews().forEach { (v, m) ->
            val sel = m == mode
            v.setTypeface(Typeface.DEFAULT, if (sel) Typeface.BOLD else Typeface.NORMAL)
            v.paintFlags = if (sel) v.paintFlags or Paint.UNDERLINE_TEXT_FLAG else v.paintFlags and Paint.UNDERLINE_TEXT_FLAG.inv()
            v.setTextColor(getColor(if (sel) R.color.cp_text else R.color.cp_text_muted))
            v.isSelected = sel
        }
    }

    private fun setupTabs() {
        styleTabs()
        tabViews().forEach { (v, m) ->
            PressFeedback.apply(v, 0.94f)
            v.setOnClickListener {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                if (m == mode && currentFolder == null) {
                    binding.recyclerCanvases.smoothScrollToPosition(0)
                    binding.appBar.setExpanded(true, true)
                    return@setOnClickListener
                }
                mode = m
                uiPrefs.edit().putString("home_tab", m.name).apply()
                currentFolder = null
                styleTabs()
                if (searching) closeSearch()
                refreshList()
                binding.appBar.setExpanded(true, true)
                fadeList()
            }
        }
    }

    private fun fadeList() {
        binding.recyclerCanvases.alpha = 0f
        binding.recyclerCanvases.animate().alpha(1f).setDuration(180).start()
    }

    /** Edge-to-edge insets, One UI sized expandable title, bottom navigation clearance. */
    private fun setupChrome() {
        val isNight = (resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, binding.root).apply {
            isAppearanceLightStatusBars = !isNight
            isAppearanceLightNavigationBars = !isNight
        }
        val d = resources.displayMetrics.density
        // One UI: the big title area takes roughly 35-40% of the screen.
        binding.collapsing.layoutParams = binding.collapsing.layoutParams.apply {
            height = (resources.displayMetrics.heightPixels * 0.34f).toInt().coerceAtLeast((220 * d).toInt())
        }
        binding.appBar.addOnOffsetChangedListener(com.google.android.material.appbar.AppBarLayout.OnOffsetChangedListener { bar, off ->
            val f = Math.abs(off).toFloat() / bar.totalScrollRange.coerceAtLeast(1)
            binding.titleBlock.alpha = (1f - f * 1.7f).coerceIn(0f, 1f)
            binding.txtTitleSmall.alpha = ((f - 0.65f) / 0.35f).coerceIn(0f, 1f)
        })
        ViewCompat.setOnApplyWindowInsetsListener(binding.rootLayout) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            binding.appBar.setPadding(bars.left, bars.top, bars.right, 0)
            binding.bottomNav.setPadding(bars.left, 0, bars.right, bars.bottom)
            (binding.fabAddCanvas.layoutParams as android.widget.FrameLayout.LayoutParams).apply {
                bottomMargin = (72 * d).toInt() + bars.bottom
                rightMargin = (20 * d).toInt() + bars.right
            }
            binding.recyclerCanvases.setPadding(
                (12 * d).toInt() + bars.left, binding.recyclerCanvases.paddingTop,
                (12 * d).toInt() + bars.right, (150 * d).toInt() + bars.bottom
            )
            insets
        }
    }

    private fun showSortDialog() {
        val labels = arrayOf(getString(R.string.sort_name), getString(R.string.sort_date_added), getString(R.string.sort_last_opened))
        val modes = arrayOf(SortMode.NAME, SortMode.DATE_ADDED, SortMode.LAST_OPENED)
        AlertDialog.Builder(this)
            .setTitle(R.string.sort_by)
            .setSingleChoiceItems(labels, modes.indexOf(currentSort)) { d, which ->
                currentSort = modes[which]
                uiPrefs.edit().putString("home_sort", currentSort.name).apply()
                d.dismiss()
                refreshList()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------------------------------------------------------------
    // List refresh (purely local)
    // ---------------------------------------------------------------------

    private fun everything(): List<CanvasProject> = deviceFiles + repository.getAll()

    private fun folderKeyOf(p: CanvasProject): String =
        if (p.isDeviceFile) p.folderName else LEGACY_KEY

    private fun modeTitle(): String = getString(
        when (mode) {
            Mode.FOLDERS -> R.string.filter_folders
            Mode.ALL -> R.string.filter_all
            Mode.FAVORITES -> R.string.filter_favorites
            Mode.RECENT -> R.string.filter_recent
        }
    )

    private fun setHeader(title: String, subtitle: String, inFolder: Boolean) {
        binding.txtTitleBig.text = title
        binding.txtTitleSmall.text = title
        (binding.txtTitleSmall.layoutParams as androidx.appcompat.widget.Toolbar.LayoutParams).marginStart =
            ((if (inFolder && !searching) 64 else 20) * resources.displayMetrics.density).toInt()
        binding.txtCount.text = subtitle
        binding.toolbar.navigationIcon =
            if (inFolder && !searching) androidx.appcompat.content.res.AppCompatResources.getDrawable(this, R.drawable.ic_back) else null
    }

    private fun filesLabel(n: Int) =
        if (n == 1) getString(R.string.files_count_one) else getString(R.string.files_count_many, n)

    private fun refreshList() {
        val all = everything()
        val searchingNow = searching && searchQuery.isNotBlank()

        // Folders overview: only when browsing folders, not inside one, not searching.
        if (mode == Mode.FOLDERS && currentFolder == null && !searchingNow && !searching) {
            val folders = all.groupBy { folderKeyOf(it) }.map { (key, files) ->
                val cover = files.filter { it.isDeviceFile && it.sourceType != CanvasProject.SourceType.MODEL }
                    .maxByOrNull { it.dateAdded } ?: files.firstOrNull()
                FolderEntry(key, folderTitle(key), files.size, cover) to (files.maxOfOrNull { it.dateAdded } ?: 0L)
            }.let { pairs ->
                if (currentSort == SortMode.NAME) pairs.sortedBy { it.first.name.lowercase() }
                else pairs.sortedByDescending { it.second }
            }.map { it.first }
            showFolders(folders)
            setHeader(
                modeTitle(),
                if (folders.size == 1) getString(R.string.folders_count_one) else getString(R.string.folders_count_many, folders.size),
                false
            )
            setEmpty(all.isEmpty(), R.string.empty_title, R.string.empty_subtitle)
            return
        }

        var list = all
        val folder = currentFolder
        if (mode == Mode.FOLDERS && folder != null && !searching) {
            list = list.filter { folderKeyOf(it) == folder.key }
        }
        list = when (mode) {
            Mode.FAVORITES -> list.filter { it.favorite }
            Mode.RECENT -> list.filter { it.lastOpened > 0L }
            else -> list
        }
        if (searchingNow) list = list.filter { it.name.contains(searchQuery, ignoreCase = true) }
        list = when {
            mode == Mode.RECENT -> list.sortedByDescending { it.lastOpened }
            currentSort == SortMode.NAME -> list.sortedBy { it.name.lowercase() }
            currentSort == SortMode.DATE_ADDED -> list.sortedByDescending { it.dateAdded }
            else -> list.sortedWith(compareByDescending<CanvasProject> { it.lastOpened }.thenByDescending { it.dateAdded })
        }

        showFiles(list)
        val inFolder = mode == Mode.FOLDERS && folder != null && !searching
        setHeader(if (inFolder) folder!!.name else modeTitle(), filesLabel(list.size), inFolder)
        when {
            searching -> setEmpty(list.isEmpty(), R.string.empty_search_title, R.string.no_results)
            mode == Mode.FAVORITES -> setEmpty(list.isEmpty(), R.string.empty_fav_title, R.string.empty_fav_subtitle)
            mode == Mode.RECENT -> setEmpty(list.isEmpty(), R.string.empty_recent_title, R.string.empty_recent_subtitle)
            else -> setEmpty(list.isEmpty(), R.string.empty_title, R.string.empty_subtitle)
        }
    }

    private fun showFolders(folders: List<FolderEntry>) {
        if (!showingFolders) {
            showingFolders = true
            binding.recyclerCanvases.layoutManager = gridManager()
            binding.recyclerCanvases.adapter = folderAdapter
        }
        folderAdapter.submit(folders)
    }

    private fun showFiles(list: List<CanvasProject>) {
        if (showingFolders) {
            showingFolders = false
            binding.recyclerCanvases.adapter = adapter
            binding.recyclerCanvases.layoutManager =
                if (adapter.viewMode == CanvasLibraryAdapter.ViewMode.GRID) gridManager() else LinearLayoutManager(this)
        }
        adapter.submitList(list)
    }

    private fun setEmpty(isEmpty: Boolean, title: Int, subtitle: Int) {
        val noAccess = binding.permissionCard.visibility == View.VISIBLE
        binding.txtEmptyTitle.setText(title)
        binding.txtEmptySubtitle.setText(subtitle)
        binding.emptyState.visibility = if (isEmpty && !noAccess && !scanning) View.VISIBLE else View.GONE
        binding.recyclerCanvases.visibility = if (isEmpty) View.INVISIBLE else View.VISIBLE
    }

    private fun folderTitle(key: String): String {
        if (key == LEGACY_KEY) return getString(R.string.saved_in_app)
        val root = android.os.Environment.getExternalStorageDirectory().absolutePath
        if (key == root) return getString(R.string.internal_storage)
        val f = File(key)
        val parent = f.parentFile?.name
        return if (parent != null && f.parentFile?.absolutePath != root) "$parent / ${f.name}" else f.name
    }

    // ---------------------------------------------------------------------
    // Opening / favoriting
    // ---------------------------------------------------------------------

    private fun openCanvas(project: CanvasProject) {
        val intent = Intent(this, CanvasViewerActivity::class.java)
        val path = project.devicePath
        if (path != null) {
            libraryPrefs.markOpened(path)
            deviceFiles = deviceFiles.map {
                if (it.id == project.id) it.copy(lastOpened = System.currentTimeMillis()) else it
            }
            lastScan = deviceFiles
            intent.putExtra(CanvasViewerActivity.EXTRA_FILE_PATH, path)
        } else {
            repository.update(project.copy(lastOpened = System.currentTimeMillis()))
            intent.putExtra(CanvasViewerActivity.EXTRA_CANVAS_ID, project.id)
        }
        startActivity(intent)
    }

    private fun toggleFavorite(project: CanvasProject) {
        val newValue = !project.favorite
        val path = project.devicePath
        if (path != null) {
            libraryPrefs.setFavorite(path, newValue)
            deviceFiles = deviceFiles.map { if (it.id == project.id) it.copy(favorite = newValue) else it }
            lastScan = deviceFiles
        } else {
            repository.update(project.copy(favorite = newValue))
        }
        refreshList()
    }

    /** "+" button: opens any file straight away; nothing is saved. */
    private fun openPickedUri(uri: Uri) {
        val displayName = FileUtils.queryDisplayName(this, uri) ?: uri.lastPathSegment ?: "file"
        val ext = FileUtils.extensionOf(displayName).ifBlank {
            SupportedFiles.extensionFromMime(contentResolver.getType(uri)) ?: ""
        }
        if (ext !in SupportedFiles.EXTENSIONS) {
            Toast.makeText(this, R.string.import_failed_unsupported, Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, R.string.importing, Toast.LENGTH_SHORT).show()
        val appContext = applicationContext
        Thread {
            val file = SupportedFiles.toLocalFile(appContext, uri, displayName, ext)
            runOnUiThread {
                if (file == null) {
                    Toast.makeText(this, R.string.import_failed, Toast.LENGTH_LONG).show()
                } else {
                    startActivity(
                        Intent(this, CanvasViewerActivity::class.java)
                            .putExtra(CanvasViewerActivity.EXTRA_FILE_PATH, file.absolutePath)
                    )
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------------
    // Per-item menu
    // ---------------------------------------------------------------------

    private fun showProjectMenu(project: CanvasProject) {
        val dialog = BottomSheetDialog(this, R.style.Theme_CanvaPlayer_BottomSheet)
        val sheetBinding = SheetProjectMenuBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(sheetBinding.root)
        applySheetBlur(dialog)

        sheetBinding.txtSheetTitle.text = project.name
        sheetBinding.txtMenuFavorite.setText(
            if (project.favorite) R.string.menu_unfavorite else R.string.menu_favorite
        )
        sheetBinding.imgMenuFavoriteIcon.setImageResource(
            if (project.favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
        )
        if (project.isDeviceFile) {
            // Files stay where they are: no renaming, and "delete" only hides it here.
            sheetBinding.menuRename.visibility = View.GONE
            sheetBinding.txtMenuDelete.setText(R.string.menu_hide)
        }

        sheetBinding.menuOpen.setOnClickListener { dialog.dismiss(); openCanvas(project) }
        sheetBinding.menuFavorite.setOnClickListener { dialog.dismiss(); toggleFavorite(project) }
        sheetBinding.menuRename.setOnClickListener { dialog.dismiss(); showRenameDialog(project) }
        sheetBinding.menuInfo.setOnClickListener { dialog.dismiss(); showInfoSheet(project) }
        sheetBinding.menuDelete.setOnClickListener {
            dialog.dismiss()
            if (project.isDeviceFile) hideFromLibrary(project) else confirmDelete(project)
        }
        dialog.show()
    }

    private fun applySheetBlur(dialog: BottomSheetDialog) {
        try {
            dialog.window?.let { w ->
                w.setDimAmount(0.18f)
                if (Build.VERSION.SDK_INT >= 31) {
                    w.addFlags(android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    w.setBackgroundBlurRadius(48)
                }
            }
        } catch (_: Throwable) { }
    }

    private fun hideFromLibrary(project: CanvasProject) {
        project.devicePath?.let { libraryPrefs.hide(it) }
        deviceFiles = deviceFiles.filter { it.id != project.id }
        lastScan = deviceFiles
        refreshList()
    }

    private fun showRenameDialog(project: CanvasProject) {
        val dialogBinding = DialogRenameBinding.inflate(LayoutInflater.from(this))
        dialogBinding.editRenameName.setText(project.name)
        dialogBinding.editRenameName.setSelection(project.name.length)

        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(dialogBinding.root)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.save) { _, _ ->
                val newName = dialogBinding.editRenameName.text?.toString()?.trim().orEmpty()
                if (newName.isNotEmpty()) {
                    repository.update(project.copy(name = newName))
                    refreshList()
                }
            }
            .show()
    }

    private fun confirmDelete(project: CanvasProject) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, project.name))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ ->
                repository.delete(project)
                refreshList()
            }
            .show()
    }

    private fun showInfoSheet(project: CanvasProject) {
        val dialog = BottomSheetDialog(this, R.style.Theme_CanvaPlayer_BottomSheet)
        val sheetBinding = SheetInfoBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(sheetBinding.root)
        applySheetBlur(dialog)

        sheetBinding.rowName.text = "${getString(R.string.info_name)}: ${project.name}"
        val path = project.devicePath
        sheetBinding.rowDateAdded.text = if (path != null)
            "${getString(R.string.info_location)}: $path"
        else
            "${getString(R.string.info_date_added)}: ${FileUtils.formatDate(project.dateAdded)}"
        sheetBinding.rowLastOpened.text =
            "${getString(R.string.info_last_opened)}: ${
                if (project.lastOpened > 0L) FileUtils.formatDate(project.lastOpened) else getString(R.string.never_opened)
            }"
        val liveSize = if (path != null) File(path).length() else FileUtils.sizeOf(repository.projectDir(project))
        sheetBinding.rowSize.text = "${getString(R.string.info_size)}: ${FileUtils.humanReadableSize(liveSize)}"
        sheetBinding.rowInternet.text = "${getString(R.string.info_internet)}: ${getString(R.string.info_offline_always)}"

        sheetBinding.btnCloseInfo.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    companion object {
        private const val LEGACY_KEY = "legacy://saved"
        /** Remembered between visits so returning from the viewer doesn't flash an empty list. */
        private var lastScan: List<CanvasProject> = emptyList()
        private var lastScanAt = 0L
        private const val RESCAN_INTERVAL_MS = 20_000L
    }
}
