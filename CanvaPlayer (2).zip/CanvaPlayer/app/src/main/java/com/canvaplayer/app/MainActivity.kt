package com.canvaplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import com.canvaplayer.app.ui.GlassLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.databinding.ActivityMainBinding
import com.canvaplayer.app.databinding.DialogRenameBinding
import com.canvaplayer.app.databinding.SheetInfoBinding
import com.canvaplayer.app.databinding.SheetProjectMenuBinding
import com.canvaplayer.app.library.DeviceScanner
import com.canvaplayer.app.library.LibraryPrefs
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.model.SortMode
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.viewer.SupportedFiles
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.io.File

/**
 * Gallery-style home screen. Supported files are found automatically on the
 * phone (like a photo gallery finds pictures) and grouped by folder; opening
 * one shows it straight from where it lives — nothing is saved or copied into
 * the app. Fully local, no network.
 */
class MainActivity : AppCompatActivity() {

    private enum class Mode { FOLDERS, ALL, FAVORITES, RECENT }

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: CanvasRepository
    private lateinit var libraryPrefs: LibraryPrefs
    private lateinit var adapter: CanvasLibraryAdapter
    private lateinit var folderAdapter: FolderAdapter

    private var mode = Mode.FOLDERS
    private var currentFolder: FolderEntry? = null
    private var currentSort = SortMode.LAST_OPENED
    private var searchQuery = ""
    private var showingFolders = false

    private var deviceFiles: List<CanvasProject> = lastScan
    @Volatile private var scanning = false
    private var forceScan = false

    private val pickFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openPickedUri(uri)
    }

    private val legacyPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startScan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupGlassChrome()

        repository = CanvasRepository.getInstance(this)
        libraryPrefs = LibraryPrefs(this)

        adapter = CanvasLibraryAdapter(
            onOpen = { openCanvas(it) },
            onToggleFavorite = { toggleFavorite(it) },
            onMoreOptions = { showProjectMenu(it) }
        )
        folderAdapter = FolderAdapter { folder ->
            currentFolder = folder
            refreshList()
        }
        binding.recyclerCanvases.adapter = adapter
        applyViewMode(loadViewMode())
        binding.btnViewToggle.setOnClickListener {
            val next = if (adapter.viewMode == CanvasLibraryAdapter.ViewMode.LIST)
                CanvasLibraryAdapter.ViewMode.GRID else CanvasLibraryAdapter.ViewMode.LIST
            saveViewMode(next)
            applyViewMode(next)
        }

        setupSearch()
        setupFilters()
        binding.btnSort.setOnClickListener { showSortMenu(it) }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.fabAddCanvas.contentDescription = getString(R.string.open_file)
        binding.fabAddCanvas.setOnClickListener { pickFileLauncher.launch(arrayOf("*/*")) }
        binding.btnGrantAccess.setOnClickListener { requestAccess() }
        binding.crumbGlass.setOnClickListener {
            currentFolder = null
            refreshList()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentFolder != null) {
                    currentFolder = null
                    refreshList()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        Thread { SupportedFiles.pruneCache(applicationContext) }.start()
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        startScan()
    }

    // ---------------------------------------------------------------------
    // Finding files
    // ---------------------------------------------------------------------

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            legacyPermissionLauncher.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun startScan() {
        val allowed = DeviceScanner.hasAccess(this)
        binding.permissionCard.visibility = if (allowed) View.GONE else View.VISIBLE
        if (!allowed) {
            deviceFiles = emptyList()
            refreshList()
            return
        }
        if (scanning) return
        // Don't re-walk the disk every time the screen comes back (e.g. from the viewer).
        val now = System.currentTimeMillis()
        if (!forceScan && lastScanAt != 0L && now - lastScanAt < RESCAN_INTERVAL_MS) {
            refreshList()
            return
        }
        forceScan = false
        scanning = true
        binding.scanProgress.visibility = View.VISIBLE
        val appContext = applicationContext
        Thread {
            val result = try { DeviceScanner.scan(appContext) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                scanning = false
                if (isDestroyed) return@runOnUiThread
                binding.scanProgress.visibility = View.GONE
                lastScan = result
                lastScanAt = System.currentTimeMillis()
                deviceFiles = result
                refreshList()
            }
        }.start()
    }

    // ---------------------------------------------------------------------
    // View mode, search, filters, sort
    // ---------------------------------------------------------------------

    private fun loadViewMode(): CanvasLibraryAdapter.ViewMode {
        val saved = getSharedPreferences("canva_player_prefs", MODE_PRIVATE).getString("view_mode", "LIST")
        return if (saved == "GRID") CanvasLibraryAdapter.ViewMode.GRID else CanvasLibraryAdapter.ViewMode.LIST
    }

    private fun saveViewMode(mode: CanvasLibraryAdapter.ViewMode) {
        getSharedPreferences("canva_player_prefs", MODE_PRIVATE).edit().putString("view_mode", mode.name).apply()
    }

    private fun applyViewMode(viewMode: CanvasLibraryAdapter.ViewMode) {
        if (!showingFolders) {
            binding.recyclerCanvases.layoutManager = if (viewMode == CanvasLibraryAdapter.ViewMode.GRID)
                GridLayoutManager(this, 2) else LinearLayoutManager(this)
        }
        adapter.viewMode = viewMode
        binding.btnViewToggle.setImageResource(
            if (viewMode == CanvasLibraryAdapter.ViewMode.GRID) R.drawable.ic_view_list else R.drawable.ic_view_grid
        )
    }

    private fun setupSearch() {
        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString().orEmpty()
                refreshList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupFilters() {
        val tabs = listOf(
            binding.tabFolders to Mode.FOLDERS,
            binding.tabAll to Mode.ALL,
            binding.tabFavorites to Mode.FAVORITES,
            binding.tabRecent to Mode.RECENT
        )
        fun select(m: Mode) {
            mode = m
            tabs.forEach { (v, tm) -> v.isSelected = tm == m }
            currentFolder = null
            refreshList()
        }
        tabs.forEach { (v, m) -> v.setOnClickListener { select(m) } }
        tabs.forEach { (v, m) -> v.isSelected = m == mode }
    }

    /** Edge-to-edge insets, list padding under the floating glass bars, glass re-blur on scroll. */
    private fun setupGlassChrome() {
        val isNight = (resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, binding.root).apply {
            isAppearanceLightStatusBars = !isNight
            isAppearanceLightNavigationBars = !isNight
        }
        val headerPad = binding.header.paddingTop
        val barPad = binding.bottomBar.paddingBottom
        var topInset = 0
        var bottomInset = 0
        fun updatePadding() {
            binding.recyclerCanvases.setPadding(
                binding.recyclerCanvases.paddingLeft,
                binding.header.height + 4,
                binding.recyclerCanvases.paddingRight,
                binding.bottomBar.height + 12
            )
            glassViews().forEach { it.refresh() }
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topInset = bars.top
            bottomInset = bars.bottom
            binding.header.setPadding(binding.header.paddingLeft, headerPad + topInset,
                binding.header.paddingRight, binding.header.paddingBottom)
            binding.bottomBar.setPadding(binding.bottomBar.paddingLeft, binding.bottomBar.paddingTop,
                binding.bottomBar.paddingRight, barPad + bottomInset)
            binding.header.post { updatePadding() }
            insets
        }
        val relayout = View.OnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (b - t != ob - ot || r - l != orr - ol) updatePadding()
        }
        binding.header.addOnLayoutChangeListener(relayout)
        binding.bottomBar.addOnLayoutChangeListener(relayout)
        binding.recyclerCanvases.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                glassViews().forEach { it.refresh() }
            }
        })
        binding.editSearch.setOnEditorActionListener { v, _, _ ->
            v.clearFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(v.windowToken, 0)
            true
        }
    }

    private fun glassViews(): List<GlassLayout> = listOf(
        binding.glassBtnViewToggle, binding.glassBtnSort, binding.glassBtnSettings,
        binding.glassSearch, binding.crumbGlass, binding.permissionCard,
        binding.glassTabs, binding.glassAdd
    )

    private fun showSortMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, getString(R.string.sort_name))
        popup.menu.add(0, 2, 1, getString(R.string.sort_date_added))
        popup.menu.add(0, 3, 2, getString(R.string.sort_last_opened))
        popup.menu.add(0, 4, 3, getString(R.string.unhide_all))
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> currentSort = SortMode.NAME
                2 -> currentSort = SortMode.DATE_ADDED
                3 -> currentSort = SortMode.LAST_OPENED
                4 -> {
                    libraryPrefs.unhideAll()
                    forceScan = true
                    startScan()
                }
            }
            refreshList()
            true
        }
        popup.show()
    }

    // ---------------------------------------------------------------------
    // List refresh (purely local)
    // ---------------------------------------------------------------------

    private fun everything(): List<CanvasProject> = deviceFiles + repository.getAll()

    private fun folderKeyOf(p: CanvasProject): String =
        if (p.isDeviceFile) p.folderName else LEGACY_KEY

    private fun refreshList() {
        val all = everything()
        val searching = searchQuery.isNotBlank()

        // Folders overview: only when browsing folders, not inside one, not searching.
        if (mode == Mode.FOLDERS && currentFolder == null && !searching) {
            val folders = all.groupBy { folderKeyOf(it) }.map { (key, files) ->
                FolderEntry(key, folderTitle(key), files.size) to (files.maxOfOrNull { it.dateAdded } ?: 0L)
            }.let { pairs ->
                if (currentSort == SortMode.NAME) pairs.sortedBy { it.first.name.lowercase() }
                else pairs.sortedByDescending { it.second }
            }.map { it.first }
            showFolders(folders)
            binding.crumbGlass.visibility = View.GONE
            setEmpty(all.isEmpty())
            return
        }

        var list = all
        val folder = currentFolder
        if (mode == Mode.FOLDERS && folder != null && !searching) {
            list = list.filter { folderKeyOf(it) == folder.key }
        }
        list = when (mode) {
            Mode.FAVORITES -> list.filter { it.favorite }
            Mode.RECENT -> list.filter { it.lastOpened > 0L }
            else -> list
        }
        if (searching) list = list.filter { it.name.contains(searchQuery, ignoreCase = true) }
        list = when (currentSort) {
            SortMode.NAME -> list.sortedBy { it.name.lowercase() }
            SortMode.DATE_ADDED -> list.sortedByDescending { it.dateAdded }
            SortMode.LAST_OPENED -> list.sortedWith(
                compareByDescending<CanvasProject> { it.lastOpened }.thenByDescending { it.dateAdded }
            )
        }

        showFiles(list)
        if (mode == Mode.FOLDERS && folder != null && !searching) {
            binding.txtCrumb.text = "‹  " + folder.name
            binding.crumbGlass.visibility = View.VISIBLE
        } else {
            binding.crumbGlass.visibility = View.GONE
        }
        setEmpty(list.isEmpty())
        binding.recyclerCanvases.post { glassViews().forEach { it.refresh() } }
    }

    private fun showFolders(folders: List<FolderEntry>) {
        if (!showingFolders) {
            showingFolders = true
            binding.recyclerCanvases.layoutManager = GridLayoutManager(this, 2)
            binding.recyclerCanvases.adapter = folderAdapter
        }
        folderAdapter.submit(folders)
    }

    private fun showFiles(list: List<CanvasProject>) {
        if (showingFolders) {
            showingFolders = false
            binding.recyclerCanvases.adapter = adapter
            binding.recyclerCanvases.layoutManager =
                if (adapter.viewMode == CanvasLibraryAdapter.ViewMode.GRID) GridLayoutManager(this, 2)
                else LinearLayoutManager(this)
        }
        adapter.submitList(list)
    }

    private fun setEmpty(isEmpty: Boolean) {
        val noAccess = binding.permissionCard.visibility == View.VISIBLE
        binding.emptyState.visibility = if (isEmpty && !noAccess && !scanning) View.VISIBLE else View.GONE
        binding.recyclerCanvases.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun folderTitle(key: String): String {
        if (key == LEGACY_KEY) return getString(R.string.saved_in_app)
        val root = android.os.Environment.getExternalStorageDirectory().absolutePath
        if (key == root) return getString(R.string.internal_storage)
        val f = File(key)
        val parent = f.parentFile?.name
        return if (parent != null && f.parentFile?.absolutePath != root) "$parent / ${f.name}" else f.name
    }

    // ---------------------------------------------------------------------
    // Opening / favoriting
    // ---------------------------------------------------------------------

    private fun openCanvas(project: CanvasProject) {
        val intent = Intent(this, CanvasViewerActivity::class.java)
        val path = project.devicePath
        if (path != null) {
            libraryPrefs.markOpened(path)
            deviceFiles = deviceFiles.map {
                if (it.id == project.id) it.copy(lastOpened = System.currentTimeMillis()) else it
            }
            lastScan = deviceFiles
            intent.putExtra(CanvasViewerActivity.EXTRA_FILE_PATH, path)
        } else {
            repository.update(project.copy(lastOpened = System.currentTimeMillis()))
            intent.putExtra(CanvasViewerActivity.EXTRA_CANVAS_ID, project.id)
        }
        startActivity(intent)
    }

    private fun toggleFavorite(project: CanvasProject) {
        val newValue = !project.favorite
        val path = project.devicePath
        if (path != null) {
            libraryPrefs.setFavorite(path, newValue)
            deviceFiles = deviceFiles.map { if (it.id == project.id) it.copy(favorite = newValue) else it }
            lastScan = deviceFiles
        } else {
            repository.update(project.copy(favorite = newValue))
        }
        refreshList()
    }

    /** "+" button: opens any file straight away; nothing is saved. */
    private fun openPickedUri(uri: Uri) {
        val displayName = FileUtils.queryDisplayName(this, uri) ?: uri.lastPathSegment ?: "file"
        val ext = FileUtils.extensionOf(displayName).ifBlank {
            SupportedFiles.extensionFromMime(contentResolver.getType(uri)) ?: ""
        }
        if (ext !in SupportedFiles.EXTENSIONS) {
            Toast.makeText(this, R.string.import_failed_unsupported, Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, R.string.importing, Toast.LENGTH_SHORT).show()
        val appContext = applicationContext
        Thread {
            val file = SupportedFiles.toLocalFile(appContext, uri, displayName, ext)
            runOnUiThread {
                if (file == null) {
                    Toast.makeText(this, R.string.import_failed, Toast.LENGTH_LONG).show()
                } else {
                    startActivity(
                        Intent(this, CanvasViewerActivity::class.java)
                            .putExtra(CanvasViewerActivity.EXTRA_FILE_PATH, file.absolutePath)
                    )
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------------
    // Per-item menu
    // ---------------------------------------------------------------------

    private fun showProjectMenu(project: CanvasProject) {
        val dialog = BottomSheetDialog(this, R.style.Theme_CanvaPlayer_BottomSheet)
        val sheetBinding = SheetProjectMenuBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(sheetBinding.root)
        applySheetBlur(dialog)

        sheetBinding.txtSheetTitle.text = project.name
        sheetBinding.txtMenuFavorite.setText(
            if (project.favorite) R.string.menu_unfavorite else R.string.menu_favorite
        )
        sheetBinding.imgMenuFavoriteIcon.setImageResource(
            if (project.favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
        )
        if (project.isDeviceFile) {
            // Files stay where they are: no renaming, and "delete" only hides it here.
            sheetBinding.menuRename.visibility = View.GONE
            sheetBinding.txtMenuDelete.setText(R.string.menu_hide)
        }

        sheetBinding.menuOpen.setOnClickListener { dialog.dismiss(); openCanvas(project) }
        sheetBinding.menuFavorite.setOnClickListener { dialog.dismiss(); toggleFavorite(project) }
        sheetBinding.menuRename.setOnClickListener { dialog.dismiss(); showRenameDialog(project) }
        sheetBinding.menuInfo.setOnClickListener { dialog.dismiss(); showInfoSheet(project) }
        sheetBinding.menuDelete.setOnClickListener {
            dialog.dismiss()
            if (project.isDeviceFile) hideFromLibrary(project) else confirmDelete(project)
        }
        dialog.show()
    }

    private fun applySheetBlur(dialog: BottomSheetDialog) {
        try {
            dialog.window?.let { w ->
                w.setDimAmount(0.18f)
                if (Build.VERSION.SDK_INT >= 31) {
                    w.addFlags(android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    w.setBackgroundBlurRadius(48)
                }
            }
        } catch (_: Throwable) { }
    }

    private fun hideFromLibrary(project: CanvasProject) {
        project.devicePath?.let { libraryPrefs.hide(it) }
        deviceFiles = deviceFiles.filter { it.id != project.id }
        lastScan = deviceFiles
        refreshList()
    }

    private fun showRenameDialog(project: CanvasProject) {
        val dialogBinding = DialogRenameBinding.inflate(LayoutInflater.from(this))
        dialogBinding.editRenameName.setText(project.name)
        dialogBinding.editRenameName.setSelection(project.name.length)

        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(dialogBinding.root)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.save) { _, _ ->
                val newName = dialogBinding.editRenameName.text?.toString()?.trim().orEmpty()
                if (newName.isNotEmpty()) {
                    repository.update(project.copy(name = newName))
                    refreshList()
                }
            }
            .show()
    }

    private fun confirmDelete(project: CanvasProject) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, project.name))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ ->
                repository.delete(project)
                refreshList()
            }
            .show()
    }

    private fun showInfoSheet(project: CanvasProject) {
        val dialog = BottomSheetDialog(this, R.style.Theme_CanvaPlayer_BottomSheet)
        val sheetBinding = SheetInfoBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(sheetBinding.root)
        applySheetBlur(dialog)

        sheetBinding.rowName.text = "${getString(R.string.info_name)}: ${project.name}"
        val path = project.devicePath
        sheetBinding.rowDateAdded.text = if (path != null)
            "${getString(R.string.info_location)}: $path"
        else
            "${getString(R.string.info_date_added)}: ${FileUtils.formatDate(project.dateAdded)}"
        sheetBinding.rowLastOpened.text =
            "${getString(R.string.info_last_opened)}: ${
                if (project.lastOpened > 0L) FileUtils.formatDate(project.lastOpened) else getString(R.string.never_opened)
            }"
        val liveSize = if (path != null) File(path).length() else FileUtils.sizeOf(repository.projectDir(project))
        sheetBinding.rowSize.text = "${getString(R.string.info_size)}: ${FileUtils.humanReadableSize(liveSize)}"
        sheetBinding.rowInternet.text = "${getString(R.string.info_internet)}: ${getString(R.string.info_offline_always)}"

        sheetBinding.btnCloseInfo.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    companion object {
        private const val LEGACY_KEY = "legacy://saved"
        /** Remembered between visits so returning from the viewer doesn't flash an empty list. */
        private var lastScan: List<CanvasProject> = emptyList()
        private var lastScanAt = 0L
        private const val RESCAN_INTERVAL_MS = 20_000L
    }
}
