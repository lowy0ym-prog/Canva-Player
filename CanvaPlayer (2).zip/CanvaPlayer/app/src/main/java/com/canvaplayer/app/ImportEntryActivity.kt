package com.canvaplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.importer.HtmlImporter
import com.canvaplayer.app.importer.ImportResult
import com.canvaplayer.app.importer.ZipImporter
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils

/**
 * Invisible router activity that lets Canva Player be launched directly from
 * a file manager ("Open with…") for a .html/.htm/.zip file. It imports the
 * file into the library exactly like the in-app "Add Canvas" flow (so it
 * also shows up under My Canvases afterwards), then opens the Canvas viewer.
 *
 * This never behaves like a browser: it only ever accepts a single local
 * file Uri handed to it by the system, copies it into private storage, and
 * hands off to the same sandboxed viewer used everywhere else in the app.
 */
class ImportEntryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uri: Uri? = intent?.data
            ?: androidx.core.content.IntentCompat.getParcelableExtra(
                intent, Intent.EXTRA_STREAM, Uri::class.java
            )
        if (uri == null) {
            finish()
            return
        }

        val displayName = FileUtils.queryDisplayName(this, uri) ?: uri.lastPathSegment ?: "Untitled"
        val extension = FileUtils.extensionOf(displayName)
        val mimeType = intent?.type

        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // Not all providers support persisting the permission; a one-shot
            // read (which is all we do) still works without it.
        }

        val isZip = extension == "zip" || mimeType == "application/zip" || mimeType == "application/x-zip-compressed"
        val isHtml = extension == "html" || extension == "htm" || mimeType == "text/html"

        val isMd = extension == "md" || extension == "markdown" || mimeType == "text/markdown"

        val isModel = extension == "glb" || extension == "gltf" ||
            mimeType == "model/gltf-binary" || mimeType == "model/gltf+json"

        val isGeo = extension == "geojson" ||
            mimeType == "application/geo+json" || mimeType == "application/vnd.geo+json"

        if (!(isZip || isHtml || isMd || isModel || isGeo)) {
            // Not something Canva Player reads: hand the file straight back to
            // Android's normal "Open with" chooser (minus this app) so other
            // apps — or the "find an app" option — are offered as usual.
            forwardToOtherApps(uri, mimeType)
            return
        }

        val result: ImportResult = when {
            isGeo -> com.canvaplayer.app.importer.GeoJsonImporter.importGeoJson(this, uri, displayName)
            isModel -> com.canvaplayer.app.importer.ModelImporter.importModel(this, uri, displayName)
            isMd -> com.canvaplayer.app.importer.MarkdownImporter.importMarkdown(this, uri, displayName)
            isZip -> ZipImporter.importZip(this, uri, displayName)
            isHtml -> HtmlImporter.importHtml(this, uri, displayName)
            else -> ImportResult.Failure(ImportResult.FailureReason.UNSUPPORTED_FILE)
        }

        when (result) {
            is ImportResult.Success -> openViewer(result.project)
            is ImportResult.Failure -> {
                val message = when (result.reason) {
                    ImportResult.FailureReason.NO_INDEX_HTML -> R.string.import_failed_no_index
                    ImportResult.FailureReason.UNSAFE_PATH -> R.string.import_failed_unsafe
                    ImportResult.FailureReason.UNSUPPORTED_FILE -> R.string.import_failed_unsupported
                    ImportResult.FailureReason.IO_ERROR -> R.string.import_failed
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun forwardToOtherApps(uri: Uri, mimeType: String?) {
        try {
            val type = mimeType?.takeIf { it != "*/*" } ?: contentResolver.getType(uri)
            val view = Intent(Intent.ACTION_VIEW).apply {
                if (type != null) setDataAndType(uri, type) else data = uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(view, null).apply {
                putExtra(
                    Intent.EXTRA_EXCLUDE_COMPONENTS,
                    arrayOf(android.content.ComponentName(this@ImportEntryActivity, ImportEntryActivity::class.java))
                )
            }
            startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed_unsupported, Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun openViewer(project: CanvasProject) {
        val updated = project.copy(lastOpened = System.currentTimeMillis())
        CanvasRepository.getInstance(this).update(updated)
        val intent = Intent(this, CanvasViewerActivity::class.java)
        intent.putExtra(CanvasViewerActivity.EXTRA_CANVAS_ID, updated.id)
        startActivity(intent)
        finish()
    }
}
