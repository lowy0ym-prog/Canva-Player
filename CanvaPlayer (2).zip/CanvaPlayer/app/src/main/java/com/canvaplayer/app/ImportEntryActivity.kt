package com.canvaplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.viewer.SupportedFiles

/**
 * Invisible router activity that lets Canva Player be launched from a file
 * manager's "Open with…" / Share sheet. A supported file is shown straight
 * away — nothing is added to the library. Anything else is handed on to other
 * apps. Never behaves like a browser: it only accepts one local file Uri.
 */
class ImportEntryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uri: Uri? = intent?.data
            ?: androidx.core.content.IntentCompat.getParcelableExtra(
                intent, Intent.EXTRA_STREAM, Uri::class.java
            )
        if (uri == null) {
            finish()
            return
        }

        val displayName = FileUtils.queryDisplayName(this, uri) ?: uri.lastPathSegment ?: "Untitled"
        val mimeType = intent?.type
        val extension = FileUtils.extensionOf(displayName).takeIf { it in SupportedFiles.EXTENSIONS }
            ?: SupportedFiles.extensionFromMime(mimeType)
            ?: SupportedFiles.extensionFromMime(contentResolver.getType(uri))

        if (extension == null) {
            // Not something Canva Player reads: hand the file straight back to
            // Android's normal "Open with" chooser (minus this app) so other
            // apps — or the "find an app" option — are offered as usual.
            forwardToOtherApps(uri, mimeType, FileUtils.extensionOf(displayName))
            return
        }

        // Open straight away, without adding anything to the library: the
        // file is used in place (file://) or copied to temporary cache space.
        val appContext = applicationContext
        Thread {
            val file = SupportedFiles.toLocalFile(appContext, uri, displayName, extension)
            runOnUiThread {
                if (file == null) {
                    Toast.makeText(this, R.string.import_failed, Toast.LENGTH_LONG).show()
                } else {
                    startActivity(
                        Intent(this, CanvasViewerActivity::class.java)
                            .putExtra(CanvasViewerActivity.EXTRA_FILE_PATH, file.absolutePath)
                    )
                }
                finish()
            }
        }.start()
    }

    private fun forwardToOtherApps(uri: Uri, mimeType: String?, extension: String?) {
        try {
            val type = mimeType?.takeIf { it != "*/*" } ?: contentResolver.getType(uri)
            val view = Intent(Intent.ACTION_VIEW).apply {
                if (type != null) setDataAndType(uri, type) else data = uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val others = packageManager
                .queryIntentActivities(view, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                .any { it.activityInfo.packageName != packageName }
            if (others) {
                val chooser = Intent.createChooser(view, null).apply {
                    putExtra(
                        Intent.EXTRA_EXCLUDE_COMPONENTS,
                        arrayOf(android.content.ComponentName(this@ImportEntryActivity, ImportEntryActivity::class.java))
                    )
                }
                startActivity(chooser)
            } else {
                searchStoreForApp(extension)
            }
        } catch (e: Exception) {
            Toast.makeText(this, R.string.no_app_for_file, Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun searchStoreForApp(extension: String?) {
        val query = if (extension.isNullOrBlank()) "file viewer" else ".$extension file viewer"
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${Uri.encode(query)}&c=apps"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(this, R.string.no_app_for_file, Toast.LENGTH_LONG).show()
        }
    }
}
