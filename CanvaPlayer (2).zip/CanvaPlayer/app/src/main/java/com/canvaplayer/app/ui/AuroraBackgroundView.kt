package com.canvaplayer.app.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/**
 * The soft, colourful "light" that Liquid Glass panels refract: a gradient
 * wash with a few large colour glows. Drawn once (static), so it costs
 * nothing while scrolling.
 */
class AuroraBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val basePaint = Paint()
    private val blobPaints = Array(4) { Paint(Paint.ANTI_ALIAS_FLAG) }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w == 0 || h == 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()
        val big = maxOf(wf, hf)

        basePaint.shader = if (night)
            LinearGradient(0f, 0f, wf, hf, 0xFF000000.toInt(), 0xFF000000.toInt(), Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, 0f, wf, hf, 0xFFF2F2F7.toInt(), 0xFFF2F2F7.toInt(), Shader.TileMode.CLAMP)

        val colors = if (night)
            intArrayOf(0x14007AFF, 0x00000000, 0x00000000, 0x00000000)
        else
            intArrayOf(0x1A007AFF, 0x00000000, 0x00000000, 0x00000000)
        val centers = arrayOf(
            floatArrayOf(0.10f * wf, 0.08f * hf, 0.75f * big),
            floatArrayOf(0.98f * wf, 0.34f * hf, 0.62f * big),
            floatArrayOf(0.05f * wf, 0.72f * hf, 0.62f * big),
            floatArrayOf(0.90f * wf, 0.98f * hf, 0.66f * big)
        )
        for (i in 0 until 4) {
            val c = centers[i]
            blobPaints[i].shader = RadialGradient(
                c[0], c[1], c[2], colors[i], colors[i] and 0x00FFFFFF, Shader.TileMode.CLAMP
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawPaint(basePaint)
        for (p in blobPaints) canvas.drawPaint(p)
    }
}
