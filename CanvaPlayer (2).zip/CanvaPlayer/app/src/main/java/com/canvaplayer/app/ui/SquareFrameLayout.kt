package com.canvaplayer.app.ui

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/** A FrameLayout that is always as tall as it is wide. */
class SquareFrameLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec)
        val w = measuredWidth
        setMeasuredDimension(w, w)
        val spec = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LayoutParams
            if (lp.width == LayoutParams.MATCH_PARENT && lp.height == LayoutParams.MATCH_PARENT) c.measure(spec, spec)
        }
    }
}
