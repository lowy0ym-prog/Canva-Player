package com.canvaplayer.app

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.canvaplayer.app.databinding.ActivitySettingsBinding
import com.canvaplayer.app.library.LibraryPrefs
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.util.ThemeManager
import java.io.File

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val night = (resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, binding.root).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.settingsRoot) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            binding.settingsAppBar.setPadding(b.left, b.top, b.right, 0)
            binding.settingsContent.setPadding(
                (12 * resources.displayMetrics.density).toInt() + b.left,
                0,
                (12 * resources.displayMetrics.density).toInt() + b.right,
                (24 * resources.displayMetrics.density).toInt() + b.bottom
            )
            // Big One UI title: about 36% of the screen while expanded.
            binding.settingsCollapsing.layoutParams = binding.settingsCollapsing.layoutParams.apply {
                height = (resources.displayMetrics.heightPixels * 0.34f).toInt()
            }
            insets
        }

        binding.settingsToolbar.setNavigationOnClickListener { finish() }
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        binding.txtVersion.text = getString(R.string.settings_version, version ?: "")
        com.canvaplayer.app.ui.PressFeedback.apply(binding.btnClearCache, 0.98f)
        com.canvaplayer.app.ui.PressFeedback.apply(binding.btnUnhide, 0.98f)

        when (ThemeManager.getSavedMode(this)) {
            ThemeManager.MODE_LIGHT -> binding.radioLight.isChecked = true
            ThemeManager.MODE_DARK -> binding.radioDark.isChecked = true
            else -> binding.radioSystem.isChecked = true
        }
        binding.radioGroupTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radioLight -> ThemeManager.MODE_LIGHT
                R.id.radioDark -> ThemeManager.MODE_DARK
                else -> ThemeManager.MODE_SYSTEM
            }
            ThemeManager.setMode(this, mode)
        }

        binding.txtUnhideSub.setText(R.string.settings_unhide_sub)
        binding.btnUnhide.setOnClickListener {
            LibraryPrefs(this).unhideAll()
            Toast.makeText(this, R.string.settings_cleared, Toast.LENGTH_SHORT).show()
        }
        binding.btnClearCache.setOnClickListener {
            val app = applicationContext
            Thread {
                cacheDirs().forEach { it.deleteRecursively() }
                com.canvaplayer.app.thumbs.Thumbnails.clearAll(app)
                runOnUiThread { showCacheSize(); Toast.makeText(this, R.string.settings_cleared, Toast.LENGTH_SHORT).show() }
            }.start()
        }
        showCacheSize()
    }

    private fun cacheDirs(): List<File> = listOf(File(cacheDir, "view"), File(cacheDir, "open"), File(filesDir, "thumbs"))

    private fun showCacheSize() {
        Thread {
            val size = cacheDirs().sumOf { dir -> dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } }
            runOnUiThread {
                binding.txtCacheSize.text = getString(R.string.settings_cache_size, FileUtils.humanReadableSize(size))
            }
        }.start()
    }
}
