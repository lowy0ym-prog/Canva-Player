package com.canvaplayer.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.canvaplayer.app.databinding.ActivitySettingsBinding
import com.canvaplayer.app.util.ThemeManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSettingsBack.setOnClickListener { finish() }

        when (ThemeManager.getSavedMode(this)) {
            ThemeManager.MODE_LIGHT -> binding.radioLight.isChecked = true
            ThemeManager.MODE_DARK -> binding.radioDark.isChecked = true
            else -> binding.radioSystem.isChecked = true
        }

        // Driven by the RadioGroup's own checked-state change, not by
        // per-button click listeners: within a RadioGroup, Android itself
        // guarantees exactly one child is checked at a time, so this is the
        // single source of truth for which option is selected.
        binding.radioGroupTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radioLight -> ThemeManager.MODE_LIGHT
                R.id.radioDark -> ThemeManager.MODE_DARK
                else -> ThemeManager.MODE_SYSTEM
            }
            ThemeManager.setMode(this, mode)
        }
    }
}
