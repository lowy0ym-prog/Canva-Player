package com.canvaplayer.app.ui

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.View
import androidx.core.content.ContextCompat
import com.canvaplayer.app.R

/**
 * Frosted-glass background like One UI's floating bars: shows a blurred copy of what is
 * behind the bar. The copy is taken on [refresh] (when the bar comes back after scrolling, when the
 * list changes), not every frame, so it costs nothing while scrolling.
 */
class BlurDrawable(
    private val ctx: Context,
    private val source: View,
    private val host: View,
    private val radiusDp: Float,
    private val tintAlpha: Int = 0x99
) : Drawable() {
    private val d = ctx.resources.displayMetrics.density
    private val scale = 1f / 7f
    private var snap: Bitmap? = null
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val tint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 0.6f * d }
    private val path = Path()

    fun refresh() {
        val w = host.width; val h = host.height
        if (w <= 0 || h <= 0 || source.width <= 0) return
        val sw = (w * scale).toInt().coerceAtLeast(2); val sh = (h * scale).toInt().coerceAtLeast(2)
        val bmp = snap?.takeIf { it.width == sw && it.height == sh } ?: Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(ContextCompat.getColor(ctx, R.color.cp_bg))
        val a = IntArray(2); val b = IntArray(2)
        host.getLocationInWindow(a); source.getLocationInWindow(b)
        c.scale(sw.toFloat() / w, sh.toFloat() / h)
        c.translate((b[0] - a[0]).toFloat(), (b[1] - a[1]).toFloat())
        try { source.draw(c) } catch (_: Throwable) {}
        blur(bmp, 3)
        snap = bmp
        invalidateSelf()
    }

    private fun blur(bmp: Bitmap, r: Int) {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        repeat(2) { boxPass(px, tmp, w, h, r, true); boxPass(tmp, px, w, h, r, false) }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    private fun boxPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
        val lines = if (horiz) h else w; val len = if (horiz) w else h
        for (l in 0 until lines) {
            for (i in 0 until len) {
                var rs = 0; var gs = 0; var bs = 0; var n = 0
                for (k in -r..r) {
                    val j = (i + k).coerceIn(0, len - 1)
                    val p = if (horiz) src[l * w + j] else src[j * w + l]
                    rs += p shr 16 and 255; gs += p shr 8 and 255; bs += p and 255; n++
                }
                val o = (255 shl 24) or (rs / n shl 16) or (gs / n shl 8) or (bs / n)
                if (horiz) dst[l * w + i] = o else dst[i * w + l] = o
            }
        }
    }

    override fun draw(canvas: Canvas) {
        val r = bounds
        val rad = radiusDp * d
        path.reset(); path.addRoundRect(RectF(r), rad, rad, Path.Direction.CW)
        val night = (ctx.resources.configuration.uiMode and 0x30) == 0x20
        canvas.save(); canvas.clipPath(path)
        snap?.let { canvas.drawBitmap(it, null, r, bmpPaint) }
        tint.color = (if (night) 0x242424 else 0xF4F4F4) or ((if (night) 0xDC else tintAlpha) shl 24)
        canvas.drawRect(RectF(r), tint)
        canvas.restore()
        border.color = if (night) 0x33FFFFFF else 0x22000000
        canvas.drawRoundRect(RectF(r).apply { inset(0.3f * d, 0.3f * d) }, rad, rad, border)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION") override fun getOpacity() = PixelFormat.TRANSLUCENT
}
